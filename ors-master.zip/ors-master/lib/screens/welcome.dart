import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:ors/api/web_api.dart';
import 'package:ors/colour_schemes.dart';
import 'package:ors/components/browser.dart';
import 'package:ors/providers/auth_provider.dart';
import 'package:ors/providers/user_provider.dart';
import 'package:provider/provider.dart';
import 'package:pin_code_fields/pin_code_fields.dart';

class Welcome extends StatefulWidget {
  const Welcome({Key? key}) : super(key: key);

  @override
  _WelcomeState createState() => _WelcomeState();
}

class _WelcomeState extends State<Welcome> {
  TextEditingController loginPhoneController = TextEditingController();
  TextEditingController loginPasswordController = TextEditingController();
  TextEditingController signupNameController = TextEditingController();
  TextEditingController signupPhoneController = TextEditingController();
  TextEditingController signupPasswordController = TextEditingController();
  TextEditingController signupConfirmPasswordController =
      TextEditingController();

  final ChromeSafariBrowser browser = OpenWebsite();

  var radioGroupValue;

  @override
  void initState() {
    super.initState();

    browser.addMenuItem(
      ChromeSafariBrowserMenuItem(
        id: 1,
        label: 'Website',
        action: (url, title) {
          debugPrint('Website opened!');
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    AuthProvider auth = AuthProvider();
    WebApi webApi = WebApi();

    OverlayEntry overlayEntry = OverlayEntry(
      builder: (context) {
        return Container(
          height: double.maxFinite,
          width: double.maxFinite,
          color: Colors.black.withOpacity(0.2),
          child: const Center(
            child: SizedBox(
              height: 30.0,
              width: 30.0,
              child: CircularProgressIndicator(color: kPrimary),
            ),
          ),
        );
      },
    );

    verifyOTP(
      String phone,
      String password,
      String otp,
      String actionType,
      String name,
      String userType,
    ) {
      TextEditingController otpController = TextEditingController();

      showDialog(
        context: context,
        builder: (context) {
          return Dialog(
            backgroundColor: Colors.white,
            elevation: 10.0,
            shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20.0),
                bottomRight: Radius.circular(20.0),
              ),
            ),
            insetPadding: const EdgeInsets.all(30.0),
            child: Padding(
              padding: const EdgeInsets.all(15.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Container(),
                      ),
                      Expanded(
                        flex: 3,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: const [
                            Text(
                              "Enter the OTP",
                              textScaleFactor: 1.15,
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: kPrimary,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            Divider(
                              color: kSecondary,
                              thickness: 3.0,
                              height: 20.0,
                              indent: 30.0,
                              endIndent: 30.0,
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                        child: Container(),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10.0),
                  const Text(
                    "OTP has been sent to your Mobile Number, please check and fill the OTP",
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.grey),
                  ),
                  const SizedBox(height: 40.0),
                  Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: PinCodeTextField(
                      appContext: context,
                      controller: otpController,
                      length: 4,
                      enablePinAutofill: true,
                      keyboardType: TextInputType.visiblePassword,
                      obscureText: true,
                      useHapticFeedback: true,
                      enableActiveFill: true,
                      cursorColor: kSecondary,
                      textStyle: const TextStyle(color: kPrimary),
                      pinTheme: PinTheme(
                        shape: PinCodeFieldShape.box,
                        fieldHeight: 50.0,
                        fieldWidth: 50.0,
                        borderRadius: BorderRadius.circular(5.0),
                        inactiveFillColor: kLightGrey.withOpacity(0.7),
                        activeFillColor: kLightGrey.withOpacity(0.7),
                        selectedFillColor: kLightGrey.withOpacity(0.7),
                        activeColor: kLightGrey.withOpacity(0.7),
                        inactiveColor: kLightGrey.withOpacity(0.7),
                        selectedColor: kLightGrey.withOpacity(0.7),
                      ),
                      onCompleted: (input) async {
                        if (actionType == "changePassword") {
                          if (otp == input) {
                            Overlay.of(context)!.insert(overlayEntry);

                            if (await webApi.setPassword(phone, password)) {
                              Fluttertoast.showToast(
                                msg: "Password changed successfully",
                                gravity: ToastGravity.BOTTOM,
                                backgroundColor: kPrimary,
                                textColor: Colors.white,
                              );
                              Navigator.of(context).pop();
                            } else {
                              Fluttertoast.showToast(
                                msg: "Password change unsuccessfull",
                                gravity: ToastGravity.BOTTOM,
                                backgroundColor: kPrimary,
                                textColor: Colors.white,
                              );
                              Navigator.of(context).pop();
                            }

                            overlayEntry.remove();
                          } else {
                            Fluttertoast.showToast(
                              msg: "Incorrect code",
                              gravity: ToastGravity.BOTTOM,
                              backgroundColor: kPrimary,
                              textColor: Colors.white,
                            );
                          }
                        } else {
                          if (otp == input) {
                            Overlay.of(context)!.insert(overlayEntry);

                            Map loginUser = await auth.signup(
                              name,
                              password,
                              phone,
                              userType,
                            );

                            overlayEntry.remove();

                            if (loginUser['status']) {
                              Navigator.of(context).pop();

                              Provider.of<OrsUserProvider>(context,
                                      listen: false)
                                  .setUser(loginUser['user']);

                              Fluttertoast.showToast(
                                msg: "Signup successful",
                                gravity: ToastGravity.BOTTOM,
                                backgroundColor: kPrimary,
                                textColor: Colors.white,
                              );
                            } else {
                              Navigator.of(context).pop();

                              Fluttertoast.showToast(
                                msg: "Account creation failed",
                                gravity: ToastGravity.BOTTOM,
                                backgroundColor: kPrimary,
                                textColor: Colors.white,
                              );
                            }
                          } else {
                            Fluttertoast.showToast(
                              msg: "Incorrect code",
                              gravity: ToastGravity.BOTTOM,
                              backgroundColor: kPrimary,
                              textColor: Colors.white,
                            );
                          }
                        }
                      },
                      onChanged: (input) {},
                    ),
                  ),
                  const SizedBox(height: 20.0),
                  const Text(
                    "Didn't received the code ?",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: kSecondary,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  TextButton(
                    onPressed: () async {
                      Map res = await webApi.getOtpByPhone(phone);

                      if (res['success']) {
                        setState(() {
                          otp = res['otp'].toString();
                        });
                        Fluttertoast.showToast(
                          msg: "OTP re-sent successfully!",
                          gravity: ToastGravity.BOTTOM,
                          backgroundColor: kPrimary,
                          textColor: Colors.white,
                        );
                      } else {
                        log(res.toString());
                        Fluttertoast.showToast(
                          msg: "OTP not sent",
                          gravity: ToastGravity.BOTTOM,
                          backgroundColor: kPrimary,
                          textColor: Colors.white,
                        );
                      }
                    },
                    child: const Text(
                      "RESEND",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: kPrimary,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      );
    }

    resetPassword() {
      TextEditingController resetPhone = TextEditingController();
      TextEditingController resetPassword = TextEditingController();
      TextEditingController resetConfirmPassword = TextEditingController();

      showDialog(
        context: context,
        builder: (context) {
          return Dialog(
            backgroundColor: Colors.white,
            elevation: 10.0,
            shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20.0),
                bottomRight: Radius.circular(20.0),
              ),
            ),
            insetPadding: const EdgeInsets.all(30.0),
            child: Padding(
              padding: const EdgeInsets.all(15.0),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          flex: 4,
                          child: Container(),
                        ),
                        Expanded(
                          child: GestureDetector(
                            onTap: () => Navigator.of(context).pop(),
                            child: const Icon(
                              Icons.close_rounded,
                              color: kSecondary,
                              size: 20.0,
                            ),
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        Expanded(
                          child: Container(),
                        ),
                        Expanded(
                          flex: 3,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: const [
                              Text(
                                "Forgot Password",
                                textScaleFactor: 1.15,
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              Divider(
                                color: kSecondary,
                                thickness: 3.0,
                                height: 20.0,
                                indent: 30.0,
                                endIndent: 30.0,
                              ),
                            ],
                          ),
                        ),
                        Expanded(
                          child: Container(),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20.0),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        "Phone number *",
                        style: TextStyle(
                          color: Colors.grey[600],
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    const SizedBox(height: 12.0),
                    TextFormField(
                      controller: resetPhone,
                      cursorRadius: const Radius.circular(50.0),
                      enableInteractiveSelection: false,
                      enableSuggestions: false,
                      keyboardType: TextInputType.phone,
                      maxLength: 10,
                      maxLines: 1,
                      style: const TextStyle(
                        color: kPrimary,
                        fontWeight: FontWeight.w500,
                      ),
                      decoration: InputDecoration(
                        contentPadding:
                            const EdgeInsets.symmetric(horizontal: 10.0),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                          borderSide: const BorderSide(
                            color: Colors.grey,
                            width: 1.2,
                          ),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                          borderSide: const BorderSide(
                            color: kPrimary,
                            width: 1.2,
                          ),
                        ),
                        counterText: '',
                      ),
                    ),
                    const SizedBox(height: 15.0),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        "New password *",
                        style: TextStyle(
                          color: Colors.grey[600],
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    const SizedBox(height: 12.0),
                    TextFormField(
                      controller: resetPassword,
                      cursorRadius: const Radius.circular(50.0),
                      enableInteractiveSelection: false,
                      enableSuggestions: false,
                      keyboardType: TextInputType.visiblePassword,
                      maxLength: 10,
                      maxLines: 1,
                      obscureText: true,
                      style: const TextStyle(
                        color: kPrimary,
                        fontWeight: FontWeight.w500,
                      ),
                      decoration: InputDecoration(
                        contentPadding:
                            const EdgeInsets.symmetric(horizontal: 10.0),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                          borderSide: const BorderSide(
                            color: Colors.grey,
                            width: 1.2,
                          ),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                          borderSide: const BorderSide(
                            color: kPrimary,
                            width: 1.2,
                          ),
                        ),
                        counterText: '',
                      ),
                    ),
                    const SizedBox(height: 15.0),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        "Confirm new password *",
                        style: TextStyle(
                          color: Colors.grey[600],
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    const SizedBox(height: 12.0),
                    TextFormField(
                      controller: resetConfirmPassword,
                      cursorRadius: const Radius.circular(50.0),
                      enableInteractiveSelection: false,
                      enableSuggestions: false,
                      keyboardType: TextInputType.visiblePassword,
                      maxLength: 10,
                      maxLines: 1,
                      obscureText: true,
                      style: const TextStyle(
                        color: kPrimary,
                        fontWeight: FontWeight.w500,
                      ),
                      decoration: InputDecoration(
                        contentPadding:
                            const EdgeInsets.symmetric(horizontal: 10.0),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                          borderSide: const BorderSide(
                            color: Colors.grey,
                            width: 1.2,
                          ),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                          borderSide: const BorderSide(
                            color: kPrimary,
                            width: 1.2,
                          ),
                        ),
                        counterText: '',
                      ),
                    ),
                    const SizedBox(height: 15.0),
                    MaterialButton(
                      onPressed: () async {
                        if (resetPhone.text.length != 10 ||
                            resetPhone.text.isEmpty ||
                            resetConfirmPassword.text.isEmpty ||
                            resetPassword.text.isEmpty) {
                          Fluttertoast.showToast(
                            msg: "Please complete all fields properly",
                            gravity: ToastGravity.BOTTOM,
                            backgroundColor: kPrimary,
                            textColor: Colors.white,
                          );
                        } else if (resetPassword.text !=
                            resetConfirmPassword.text) {
                          Fluttertoast.showToast(
                            msg: "Password & Confirm password are not same",
                            gravity: ToastGravity.BOTTOM,
                            backgroundColor: kPrimary,
                            textColor: Colors.white,
                          );
                        } else {
                          Overlay.of(context)!.insert(overlayEntry);
                          Map response =
                              await webApi.getOtpByPhone(resetPhone.text);

                          overlayEntry.remove();

                          if (response['success']) {
                            Fluttertoast.showToast(
                              msg: "OTP sent successfully!",
                              gravity: ToastGravity.BOTTOM,
                              backgroundColor: kPrimary,
                              textColor: Colors.white,
                            );
                            Navigator.of(context).pop();
                            verifyOTP(
                              resetPhone.text,
                              resetPassword.text,
                              response['otp'].toString(),
                              "changePassword",
                              '',
                              '',
                            );
                          } else {
                            log(response.toString());
                            Fluttertoast.showToast(
                              msg: "OTP not sent!",
                              gravity: ToastGravity.BOTTOM,
                              backgroundColor: kPrimary,
                              textColor: Colors.white,
                            );
                          }
                        }
                      },
                      color: kPrimary,
                      elevation: 0.0,
                      height: 40.0,
                      minWidth: MediaQuery.of(context).size.width * 0.45,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10.0)),
                      child: const Text(
                        "Submit",
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      );
    }

    initAuth(int i) {
      showModalBottomSheet(
        context: context,
        backgroundColor: Colors.white,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(25.0),
            topRight: Radius.circular(25.0),
          ),
        ),
        isDismissible: false,
        isScrollControlled: true,
        constraints: BoxConstraints(
            maxHeight: MediaQuery.of(context).size.height * 0.75),
        builder: (context) {
          return Container(
            height: double.maxFinite,
            width: double.maxFinite,
            margin: const EdgeInsets.all(25.0),
            child: DefaultTabController(
              length: 2,
              initialIndex: i,
              child: Column(
                children: [
                  Flexible(
                    child: Align(
                      alignment: Alignment.topCenter,
                      child: Container(
                        height: 6.0,
                        width: 60.0,
                        decoration: BoxDecoration(
                          color: kPrimary,
                          borderRadius: BorderRadius.circular(50.0),
                        ),
                      ),
                    ),
                  ),
                  const Expanded(
                    child: TabBar(
                      labelColor: kSecondary,
                      unselectedLabelColor: Colors.grey,
                      indicatorColor: kPrimary,
                      indicatorSize: TabBarIndicatorSize.label,
                      indicatorWeight: 2.5,
                      tabs: [
                        Tab(
                          text: "Create Account",
                        ),
                        Tab(
                          text: "Login",
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    flex: 10,
                    child: TabBarView(
                      children: [
                        SingleChildScrollView(
                          padding: const EdgeInsets.only(
                              top: 10.0, left: 5.0, right: 5.0),
                          child: Column(
                            children: [
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Text(
                                  "Name *",
                                  style: TextStyle(
                                    color: Colors.grey[600],
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 12.0),
                              TextFormField(
                                controller: signupNameController,
                                cursorRadius: const Radius.circular(50.0),
                                enableInteractiveSelection: false,
                                enableSuggestions: false,
                                keyboardType: TextInputType.name,
                                maxLines: 1,
                                style: const TextStyle(
                                  color: kPrimary,
                                  fontWeight: FontWeight.w500,
                                ),
                                decoration: InputDecoration(
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                    borderSide: const BorderSide(
                                      color: Colors.grey,
                                      width: 1.2,
                                    ),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                    borderSide: const BorderSide(
                                      color: kPrimary,
                                      width: 1.2,
                                    ),
                                  ),
                                  counterText: '',
                                ),
                              ),
                              const SizedBox(height: 15.0),
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Text(
                                  "Phone number *",
                                  style: TextStyle(
                                    color: Colors.grey[600],
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 12.0),
                              TextFormField(
                                controller: signupPhoneController,
                                cursorRadius: const Radius.circular(50.0),
                                enableInteractiveSelection: false,
                                enableSuggestions: false,
                                keyboardType: TextInputType.phone,
                                maxLength: 10,
                                maxLines: 1,
                                style: const TextStyle(
                                  color: kPrimary,
                                  fontWeight: FontWeight.w500,
                                ),
                                decoration: InputDecoration(
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                    borderSide: const BorderSide(
                                      color: Colors.grey,
                                      width: 1.2,
                                    ),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                    borderSide: const BorderSide(
                                      color: kPrimary,
                                      width: 1.2,
                                    ),
                                  ),
                                  counterText: '',
                                ),
                              ),
                              const SizedBox(height: 15.0),
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Text(
                                  "Password *",
                                  style: TextStyle(
                                    color: Colors.grey[600],
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 12.0),
                              TextFormField(
                                controller: signupPasswordController,
                                cursorRadius: const Radius.circular(50.0),
                                enableInteractiveSelection: false,
                                enableSuggestions: false,
                                obscureText: true,
                                keyboardType: TextInputType.visiblePassword,
                                maxLines: 1,
                                style: const TextStyle(
                                  color: kPrimary,
                                  fontWeight: FontWeight.w500,
                                ),
                                decoration: InputDecoration(
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                    borderSide: const BorderSide(
                                      color: Colors.grey,
                                      width: 1.2,
                                    ),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                    borderSide: const BorderSide(
                                      color: kPrimary,
                                      width: 1.2,
                                    ),
                                  ),
                                  counterText: '',
                                ),
                              ),
                              const SizedBox(height: 15.0),
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Text(
                                  "Confirm password *",
                                  style: TextStyle(
                                    color: Colors.grey[600],
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 12.0),
                              TextFormField(
                                controller: signupConfirmPasswordController,
                                cursorRadius: const Radius.circular(50.0),
                                enableInteractiveSelection: false,
                                enableSuggestions: false,
                                obscureText: true,
                                keyboardType: TextInputType.visiblePassword,
                                maxLines: 1,
                                style: const TextStyle(
                                  color: kPrimary,
                                  fontWeight: FontWeight.w500,
                                ),
                                decoration: InputDecoration(
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                    borderSide: const BorderSide(
                                      color: Colors.grey,
                                      width: 1.2,
                                    ),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                    borderSide: const BorderSide(
                                      color: kPrimary,
                                      width: 1.2,
                                    ),
                                  ),
                                  counterText: '',
                                ),
                              ),
                              const SizedBox(height: 15.0),
                              StatefulBuilder(
                                builder: (BuildContext context, setState) {
                                  return Column(
                                    children: [
                                      Row(
                                        children: [
                                          Expanded(
                                            child: Row(
                                              children: [
                                                Flexible(
                                                  child: Center(
                                                    child: Radio(
                                                      value: "Company",
                                                      groupValue:
                                                          radioGroupValue,
                                                      activeColor: kSecondary,
                                                      onChanged: (input) {
                                                        setState(() {
                                                          radioGroupValue =
                                                              input;
                                                        });
                                                      },
                                                    ),
                                                  ),
                                                ),
                                                Flexible(
                                                  flex: 2,
                                                  child: Align(
                                                    alignment:
                                                        Alignment.centerLeft,
                                                    child: GestureDetector(
                                                      onTap: () {
                                                        setState(() {
                                                          radioGroupValue =
                                                              "Company";
                                                        });
                                                      },
                                                      child: const Text(
                                                        "Company",
                                                        //textScaleFactor: 0.75,
                                                        textAlign:
                                                            TextAlign.center,
                                                        style: TextStyle(
                                                          color: Colors.black,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Expanded(
                                            child: Row(
                                              children: [
                                                Flexible(
                                                  child: Center(
                                                    child: Radio(
                                                      value: "Customer",
                                                      groupValue:
                                                          radioGroupValue,
                                                      activeColor: kSecondary,
                                                      onChanged: (input) {
                                                        setState(() {
                                                          radioGroupValue =
                                                              input;
                                                        });
                                                      },
                                                    ),
                                                  ),
                                                ),
                                                Flexible(
                                                  flex: 2,
                                                  child: Align(
                                                    alignment:
                                                        Alignment.centerLeft,
                                                    child: GestureDetector(
                                                      onTap: () {
                                                        setState(() {
                                                          radioGroupValue =
                                                              "Customer";
                                                        });
                                                      },
                                                      child: const Text(
                                                        "Customer",
                                                        //textScaleFactor: 0.75,
                                                        textAlign:
                                                            TextAlign.center,
                                                        style: TextStyle(
                                                          color: Colors.black,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                      Row(
                                        children: [
                                          Expanded(
                                            child: Row(
                                              children: [
                                                Flexible(
                                                  child: Center(
                                                    child: Radio(
                                                      value: "Driver",
                                                      groupValue:
                                                          radioGroupValue,
                                                      activeColor: kSecondary,
                                                      onChanged: (input) {
                                                        setState(() {
                                                          radioGroupValue =
                                                              input;
                                                        });
                                                      },
                                                    ),
                                                  ),
                                                ),
                                                Flexible(
                                                  flex: 2,
                                                  child: Align(
                                                    alignment:
                                                        Alignment.centerLeft,
                                                    child: GestureDetector(
                                                      onTap: () {
                                                        setState(() {
                                                          radioGroupValue =
                                                              "Driver";
                                                        });
                                                      },
                                                      child: const Text(
                                                        "Driver",
                                                        //textScaleFactor: 0.75,
                                                        textAlign:
                                                            TextAlign.center,
                                                        style: TextStyle(
                                                          color: Colors.black,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Expanded(
                                            child: Row(
                                              children: [
                                                Flexible(
                                                  child: Center(
                                                    child: Radio(
                                                      value: "Owner",
                                                      groupValue:
                                                          radioGroupValue,
                                                      activeColor: kSecondary,
                                                      onChanged: (input) {
                                                        setState(() {
                                                          radioGroupValue =
                                                              input;
                                                        });
                                                      },
                                                    ),
                                                  ),
                                                ),
                                                Flexible(
                                                  flex: 2,
                                                  child: Align(
                                                    alignment:
                                                        Alignment.centerLeft,
                                                    child: GestureDetector(
                                                      onTap: () {
                                                        setState(() {
                                                          radioGroupValue =
                                                              "Owner";
                                                        });
                                                      },
                                                      child: const Text(
                                                        "Owner",
                                                        //textScaleFactor: 0.75,
                                                        textAlign:
                                                            TextAlign.center,
                                                        style: TextStyle(
                                                          color: Colors.black,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  );
                                },
                              ),
                              const SizedBox(height: 15.0),
                              MaterialButton(
                                onPressed: () async {
                                  if (signupPhoneController.text.length != 10 ||
                                      signupPhoneController.text.isEmpty ||
                                      signupPasswordController.text.isEmpty ||
                                      signupConfirmPasswordController
                                          .text.isEmpty ||
                                      signupNameController.text.isEmpty ||
                                      radioGroupValue == null) {
                                    Fluttertoast.showToast(
                                      msg:
                                          "Please complete all fields properly",
                                      gravity: ToastGravity.BOTTOM,
                                      backgroundColor: kPrimary,
                                      textColor: Colors.white,
                                    );
                                  } else {
                                    Overlay.of(context)!.insert(overlayEntry);

                                    bool checkNum = await webApi.verifyPhone(
                                        signupPhoneController.text);

                                    if (checkNum) {
                                      overlayEntry.remove();

                                      Fluttertoast.showToast(
                                        msg: "Phone number already registered!",
                                        gravity: ToastGravity.BOTTOM,
                                        backgroundColor: kPrimary,
                                        textColor: Colors.white,
                                      );
                                    } else {
                                      Map response = await webApi.getOtpByPhone(
                                          signupPhoneController.text);

                                      overlayEntry.remove();

                                      if (response['success']) {
                                        Fluttertoast.showToast(
                                          msg: "OTP sent successfully!",
                                          gravity: ToastGravity.BOTTOM,
                                          backgroundColor: kPrimary,
                                          textColor: Colors.white,
                                        );
                                        Navigator.of(context).pop();
                                        verifyOTP(
                                          signupPhoneController.text,
                                          signupPasswordController.text,
                                          response['otp'].toString(),
                                          "register",
                                          signupNameController.text,
                                          radioGroupValue.toString(),
                                        );
                                      } else {
                                        log(response.toString());
                                        Fluttertoast.showToast(
                                          msg: "OTP not sent!",
                                          gravity: ToastGravity.BOTTOM,
                                          backgroundColor: kPrimary,
                                          textColor: Colors.white,
                                        );
                                      }
                                    }
                                  }
                                },
                                color: kPrimary,
                                elevation: 0.0,
                                height: 50.0,
                                minWidth:
                                    MediaQuery.of(context).size.width * 0.55,
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10.0)),
                                child: const Text(
                                  "Registration",
                                  style: TextStyle(color: Colors.white),
                                ),
                              ),
                              SizedBox(
                                  height:
                                      MediaQuery.of(context).viewInsets.bottom),
                            ],
                          ),
                        ),
                        SingleChildScrollView(
                          padding: const EdgeInsets.only(
                              top: 10.0, left: 5.0, right: 5.0),
                          child: Column(
                            children: [
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Text(
                                  "Phone number *",
                                  style: TextStyle(
                                    color: Colors.grey[600],
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 12.0),
                              TextFormField(
                                controller: loginPhoneController,
                                cursorRadius: const Radius.circular(50.0),
                                enableInteractiveSelection: false,
                                enableSuggestions: false,
                                keyboardType: TextInputType.phone,
                                maxLength: 10,
                                maxLines: 1,
                                style: const TextStyle(
                                  color: kPrimary,
                                  fontWeight: FontWeight.w500,
                                ),
                                decoration: InputDecoration(
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                    borderSide: const BorderSide(
                                      color: Colors.grey,
                                      width: 1.2,
                                    ),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                    borderSide: const BorderSide(
                                      color: kPrimary,
                                      width: 1.2,
                                    ),
                                  ),
                                  counterText: '',
                                ),
                              ),
                              const SizedBox(height: 15.0),
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Text(
                                  "Password *",
                                  style: TextStyle(
                                    color: Colors.grey[600],
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 12.0),
                              TextFormField(
                                controller: loginPasswordController,
                                cursorRadius: const Radius.circular(50.0),
                                enableInteractiveSelection: false,
                                enableSuggestions: false,
                                keyboardType: TextInputType.visiblePassword,
                                maxLength: 10,
                                maxLines: 1,
                                obscureText: true,
                                style: const TextStyle(
                                  color: kPrimary,
                                  fontWeight: FontWeight.w500,
                                ),
                                decoration: InputDecoration(
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                    borderSide: const BorderSide(
                                      color: Colors.grey,
                                      width: 1.2,
                                    ),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                    borderSide: const BorderSide(
                                      color: kPrimary,
                                      width: 1.2,
                                    ),
                                  ),
                                  counterText: '',
                                ),
                              ),
                              //const SizedBox(height: 10.0),
                              Align(
                                alignment: Alignment.centerRight,
                                child: TextButton(
                                  onPressed: () => resetPassword(),
                                  child: const Text(
                                    "Forgot Password ?",
                                    style: TextStyle(
                                      color: kSecondary,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(height: 5.0),
                              MaterialButton(
                                onPressed: () async {
                                  if (loginPhoneController.text.length != 10 ||
                                      loginPhoneController.text.isEmpty ||
                                      loginPasswordController.text.isEmpty) {
                                    Fluttertoast.showToast(
                                      msg:
                                          "Please complete all fields properly",
                                      gravity: ToastGravity.BOTTOM,
                                      backgroundColor: kPrimary,
                                      textColor: Colors.white,
                                    );
                                  } else {
                                    Overlay.of(context)!.insert(overlayEntry);

                                    Map loginUser = await auth.login(
                                        loginPhoneController.text,
                                        loginPasswordController.text);

                                    overlayEntry.remove();

                                    if (loginUser['status']) {
                                      Navigator.of(context).pop();

                                      Provider.of<OrsUserProvider>(context,
                                              listen: false)
                                          .setUser(loginUser['user']);

                                      Fluttertoast.showToast(
                                        msg: "Login successful",
                                        gravity: ToastGravity.BOTTOM,
                                        backgroundColor: kPrimary,
                                        textColor: Colors.white,
                                      );
                                    } else {
                                      Fluttertoast.showToast(
                                        msg:
                                            "Please provide correct credentials",
                                        gravity: ToastGravity.BOTTOM,
                                        backgroundColor: kPrimary,
                                        textColor: Colors.white,
                                      );
                                    }
                                  }
                                },
                                color: kPrimary,
                                elevation: 0.0,
                                height: 50.0,
                                minWidth:
                                    MediaQuery.of(context).size.width * 0.55,
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10.0)),
                                child: const Text(
                                  "Login",
                                  style: TextStyle(color: Colors.white),
                                ),
                              ),
                              SizedBox(
                                  height:
                                      MediaQuery.of(context).viewInsets.bottom),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      );
    }

    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.grey[200],
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 30.0),
          child: Column(
            children: [
              Expanded(
                flex: 4,
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Center(
                      child: Image.asset('assets/images/Group 3184.png')),
                ),
              ),
              Expanded(
                flex: 3,
                child: Column(
                  children: const [
                    Expanded(
                      child: Align(
                        alignment: Alignment.bottomCenter,
                        child: Text(
                          "Welcome",
                          textScaleFactor: 1.3,
                          style: TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Center(
                        child: Text(
                          "Find Road Service Near You With Ease, Stop worrying on the road, have your backup. Fast and Reliable help for your emergency!",
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.black),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                flex: 3,
                child: Column(
                  children: [
                    Expanded(
                      child: Align(
                        alignment: Alignment.bottomCenter,
                        child: MaterialButton(
                          onPressed: () => initAuth(0),
                          color: kPrimary,
                          elevation: 0.0,
                          enableFeedback: true,
                          height: MediaQuery.of(context).size.height * 0.07,
                          minWidth: MediaQuery.of(context).size.width * 0.65,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12.0)),
                          child: const Text(
                            "Create Account",
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                      child: Center(
                        child: MaterialButton(
                          onPressed: () => initAuth(1),
                          color: kPrimary,
                          elevation: 0.0,
                          enableFeedback: true,
                          height: MediaQuery.of(context).size.height * 0.07,
                          minWidth: MediaQuery.of(context).size.width * 0.65,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12.0)),
                          child: const Text(
                            "Login",
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                flex: 2,
                child: Wrap(
                  alignment: WrapAlignment.center,
                  runAlignment: WrapAlignment.center,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  textDirection: TextDirection.ltr,
                  children: [
                    const Text(
                      "By logging in or registering, you're agreeing to",
                    ),
                    TextButton(
                      onPressed: () async {
                        await browser.open(
                          url: Uri.parse('https://onlineroadservices.com/terms'),
                          options: ChromeSafariBrowserClassOptions(
                            android: AndroidChromeCustomTabsOptions(
                              addDefaultShareMenuItem: true,
                            ),
                            ios: IOSSafariOptions(
                              barCollapsingEnabled: true,
                            ),
                          ),
                        );
                      },
                      style: ButtonStyle(
                          padding: MaterialStateProperty.all(EdgeInsets.zero)),
                      child: const Text(
                        "The Terms and Conditions",
                        style: TextStyle(color: kSecondary),
                      ),
                    ),
                    const Text(
                      "  and  ",
                    ),
                    TextButton(
                      onPressed: () async {
                        await browser.open(
                          url: Uri.parse('https://onlineroadservices.com/policy'),
                          options: ChromeSafariBrowserClassOptions(
                            android: AndroidChromeCustomTabsOptions(
                              addDefaultShareMenuItem: true,
                            ),
                            ios: IOSSafariOptions(
                              barCollapsingEnabled: true,
                            ),
                          ),
                        );
                      },
                      style: ButtonStyle(
                          padding: MaterialStateProperty.all(EdgeInsets.zero)),
                      child: const Text(
                        "Privacy Policy.",
                        style: TextStyle(color: kSecondary),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
