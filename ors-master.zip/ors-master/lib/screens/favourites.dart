import 'package:flutter/material.dart';
import 'package:ors/api/web_api.dart';
import 'package:ors/colour_schemes.dart';
import 'package:ors/models/data_model.dart';
import 'package:ors/models/user_model.dart';
import 'package:ors/providers/user_provider.dart';
import 'package:ors/widgets/ads_card.dart';
import 'package:ors/widgets/drawer.dart';
import 'package:provider/provider.dart';

class Favourites extends StatefulWidget {
  const Favourites({Key? key}) : super(key: key);

  @override
  _FavouritesState createState() => _FavouritesState();
}

class _FavouritesState extends State<Favourites> {
  GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    OrsUser orsUser =
        Provider.of<OrsUserProvider>(context, listen: false).user!;

    Future<List<FavAd>> getFavs() =>
        WebApi().getFavouritesList(orsUser.userId.toString());

    return Scaffold(
      key: scaffoldKey,
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.grey[200],
      endDrawer: const GlobalDrawer(),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: Stack(
                children: [
                  SizedBox(
                    height: double.maxFinite,
                    width: double.maxFinite,
                    child: Image.asset(
                      'assets/images/3 3.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                  const Align(
                    alignment: Alignment.centerLeft,
                    child: Padding(
                      padding: EdgeInsets.only(left: 15.0),
                      child: Text(
                        "Favourite",
                        textScaleFactor: 1.2,
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ),
                  Align(
                    alignment: Alignment.centerRight,
                    child: IconButton(
                      onPressed: () =>
                          scaffoldKey.currentState!.openEndDrawer(),
                      color: Colors.white,
                      iconSize: 28.0,
                      icon: const ImageIcon(
                          AssetImage('assets/icon/feather_bar-chart-2.png')),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              flex: 4,
              child: FutureBuilder<List<FavAd>>(
                future: getFavs(),
                builder: (context, snapshot) {
                  if (snapshot.hasData) {
                    if (snapshot.data!.isEmpty) {
                      return const Center(
                        child: Text(
                          "No favourite items!",
                          textScaleFactor: 1.15,
                        ),
                      );
                    } else {
                      return ListView.builder(
                        itemCount: snapshot.data!.length,
                        itemBuilder: (context, index) {
                          return Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 12.0, vertical: 5.0),
                            child: AdsCard(
                              ad: snapshot.data![index].ad,
                              isEditableAd: true,
                              isDetails: false,
                              favID: snapshot.data![index].favAdId.toString(),
                              onDelete: (data) {
                                setState(() {});
                              },
                              favIds: const [],
                            ),
                          );
                        },
                      );
                    }
                  } else {
                    return const Center(
                      child: SizedBox(
                        height: 40.0,
                        width: 40.0,
                        child: CircularProgressIndicator(color: kPrimary),
                      ),
                    );
                  }
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
