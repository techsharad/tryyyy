import 'package:flutter/material.dart';
import 'package:ors/api/web_api.dart';
import 'package:ors/models/data_model.dart';
import 'package:ors/providers/location_provider.dart';
import 'package:provider/provider.dart';

class SearchPage extends StatefulWidget {
  const SearchPage({Key? key}) : super(key: key);

  @override
  _SearchPageState createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  String? mydata;

  @override
  Widget build(BuildContext context) {
    var tempTest = Provider.of<LocationProvider>(context, listen: false);

    return const Scaffold();

    /*return Consumer<LocationProvider>(
      builder: (context, data, w) {
        return Scaffold(
          floatingActionButton: FloatingActionButton(
            onPressed: () async {
              var temp = await tempTest.getLocationDetails(
                Places(
                    id: 'ChIJnU6eVOFdlIAREbijSWRAEns', name: 'Fresno, CA, USA'),
              );

              mydata = temp['place'].state +
                  ", " +
                  temp['place'].city +
                  ", " +
                  temp['place'].country;
            },
          ),
          body: SafeArea(
            child: Center(
              child: Text(mydata.toString()),
            ),
          ),
        );
      },
    );*/
  }
}
