import 'package:flutter/material.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:ors/api/web_api.dart';
import 'package:ors/colour_schemes.dart';
import 'package:ors/models/data_model.dart';
import 'package:ors/test.dart';
import 'package:ors/widgets/ads_card.dart';
import 'package:ors/widgets/custom_dropdown.dart';
import 'package:ors/widgets/drawer.dart';
import 'package:persistent_bottom_nav_bar/persistent-tab-view.dart';

class SearchResults extends StatefulWidget {
  final String selectedCategory,
      selectedCategoryName,
      selectedMainCategory,
      selectedMainCategoryName;
  final Places selectedPlace;
  final List<int> favIds;

  const SearchResults({
    Key? key,
    required this.selectedCategory,
    required this.selectedCategoryName,
    required this.selectedMainCategory,
    required this.selectedMainCategoryName,
    required this.selectedPlace,
    required this.favIds,
  }) : super(key: key);

  @override
  _SearchResultsState createState() => _SearchResultsState();
}

class _SearchResultsState extends State<SearchResults> {
  GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();

  final PagingController<int, OrsAds> pagingController =
      PagingController(firstPageKey: 1);

  WebApi webApi = WebApi();

  bool filterActive = false;

  String? selectedMainCategory;
  String? selectedMainCategoryName;
  String? selectedCategory;
  String? selectedCategoryName;
  Places? selectedPlace;

  Places? selectedLocation;

  List<MainCategory>? _mainCategories;
  List<OrsCategory>? _categories;

  @override
  void initState() {
    super.initState();

    selectedMainCategory = widget.selectedMainCategory;
    selectedMainCategoryName = widget.selectedMainCategoryName;
    selectedCategory = widget.selectedCategory;
    selectedCategoryName = widget.selectedCategoryName;
    selectedPlace = widget.selectedPlace;

    pagingController.addPageRequestListener((pageKey) {
      _fetchData(pageKey);
    });

    getCategoryLists();
  }

  getCategoryLists() async {}

  Future<void> _fetchData(int index) async {
    try {
      final newItems = await webApi.getSearchResultData(
        selectedMainCategory.toString(),
        selectedCategory.toString(),
        selectedPlace!.country.toString(),
        selectedPlace!.state.toString(),
        selectedPlace!.city.toString(),
        selectedPlace!.name,
        selectedPlace!.lat.toString(),
        selectedPlace!.lng.toString(),
        'NA',
        'NA',
        'NA',
        index.toString(),
      );

      final isLastPage = newItems.length < 9;

      if (isLastPage) {
        pagingController.appendLastPage(newItems);
      } else {
        final nextPageKey = index + 1;
        pagingController.appendPage(newItems, nextPageKey);
      }
    } catch (e) {
      pagingController.error = e;
    }
  }

  String? mainCategoryIdForFilter;

  int selectedMainCategoryIndex = 0;
  int selectedCategoryIndex = 0;

  @override
  Widget build(BuildContext context) {
    Future<List<MainCategory>> getMainCategory() =>
        webApi.getMainCategoryList();
    Future<List<OrsCategory>> getCategory() =>
        webApi.getCategoryList(selectedMainCategory.toString());

    refreshDataWithFilter(/*Places? location*/) {
      Navigator.of(context).pop();

      pushNewScreen(
        context,
        screen: SearchResults(
          selectedCategory: selectedCategory.toString(),
          selectedCategoryName: selectedCategoryName.toString(),
          selectedMainCategory: selectedMainCategory.toString(),
          selectedMainCategoryName: selectedMainCategoryName.toString(),
          selectedPlace: selectedPlace as Places,
          //  (location == null) ? selectedPlace as Places : location,
          favIds: widget.favIds,
        ),
        withNavBar: false,
        pageTransitionAnimation: PageTransitionAnimation.fade,
      );
    }

    return Scaffold(
      key: scaffoldKey,
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.grey[200],
      endDrawer: const GlobalDrawer(),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: Stack(
                children: [
                  SizedBox(
                    height: double.maxFinite,
                    width: double.maxFinite,
                    child: Image.asset(
                      'assets/images/3 3.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                  const Align(
                    alignment: Alignment.topLeft,
                    child: BackButton(color: Colors.white),
                  ),
                  Align(
                    alignment: Alignment.topRight,
                    child: IconButton(
                      onPressed: () =>
                          scaffoldKey.currentState!.openEndDrawer(),
                      color: Colors.white,
                      iconSize: 28.0,
                      icon: const ImageIcon(
                          AssetImage('assets/icon/feather_bar-chart-2.png')),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              flex: 5,
              child: Column(
                children: [
                  (filterActive)
                      ? Expanded(
                          flex: 7,
                          child: Card(
                            elevation: 8.0,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10.0)),
                            margin: const EdgeInsets.symmetric(
                              horizontal: 20.0,
                              vertical: 10.0,
                            ),
                            child: SizedBox.expand(
                              child: Column(
                                children: [
                                  Expanded(
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Flexible(
                                          child: Padding(
                                            padding: const EdgeInsets.only(
                                                left: 10.0),
                                            child: GestureDetector(
                                              onTap: () {
                                                setState(() {
                                                  filterActive = !filterActive;
                                                });
                                              },
                                              child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: const [
                                                  Flexible(
                                                    child: Icon(
                                                      Icons.filter_list_rounded,
                                                      color: kSecondary,
                                                    ),
                                                  ),
                                                  Flexible(
                                                      child:
                                                          SizedBox(width: 3.0)),
                                                  Flexible(
                                                    child: Text(
                                                      "FILTER",
                                                      style: TextStyle(
                                                        color: Colors.black,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                        Flexible(
                                          child: (filterActive)
                                              ? Padding(
                                                  padding:
                                                      const EdgeInsets.all(5.0),
                                                  child: MaterialButton(
                                                    onPressed: () =>
                                                        refreshDataWithFilter(),
                                                    child: const Text(
                                                      "Apply filters",
                                                      textScaleFactor: 0.75,
                                                      style: TextStyle(
                                                        color: Colors.white,
                                                        fontWeight:
                                                            FontWeight.w600,
                                                      ),
                                                    ),
                                                    color: kPrimary,
                                                    shape:
                                                        const StadiumBorder(),
                                                  ),
                                                )
                                              : Container(),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Expanded(
                                    child: ListView.separated(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 12.0),
                                      scrollDirection: Axis.horizontal,
                                      itemBuilder: (context, index) {
                                        List items = [
                                          selectedMainCategoryName,
                                          selectedCategoryName,
                                          (selectedPlace == null)
                                              ? "Location not selected"
                                              : selectedPlace!.city,
                                        ];

                                        return Center(
                                          child: Text(
                                            items[index],
                                            style: TextStyle(
                                                color: Colors.grey[600]),
                                          ),
                                        );
                                      },
                                      separatorBuilder: (context, index) {
                                        return const RotatedBox(
                                          quarterTurns: 1,
                                          child: Divider(
                                            thickness: 1.5,
                                            endIndent: 5,
                                            indent: 5,
                                            height: 20.0,
                                          ),
                                        );
                                      },
                                      itemCount: 3,
                                    ),
                                  ),
                                  Expanded(
                                    flex: 2,
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: kLightGrey.withOpacity(0.3),
                                        borderRadius:
                                            BorderRadius.circular(50.0),
                                      ),
                                      margin: const EdgeInsets.symmetric(
                                        vertical: 12.0,
                                        horizontal: 8.0,
                                      ),
                                      child: MyDropdown(
                                        title: "Location",
                                        titleColor: kPrimary,
                                        icon: const Icon(
                                          Icons.location_on_rounded,
                                          color: kSecondary,
                                          size: 16.0,
                                        ),
                                        value: selectedLocation,
                                        onChanged: (value) {
                                          setState(() {
                                            selectedPlace = value;
                                          });
                                        },
                                        isAddressField: true,
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    flex: 3,
                                    child: FutureBuilder<List<MainCategory>>(
                                      future: getMainCategory(),
                                      builder: (BuildContext context,
                                          AsyncSnapshot snapshot) {
                                        return Padding(
                                          padding: const EdgeInsets.symmetric(
                                            vertical: 4.0,
                                            horizontal: 8.0,
                                          ),
                                          child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceEvenly,
                                            children: [
                                              Flexible(
                                                child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: const [
                                                    Flexible(
                                                      child: Text(
                                                        'Main Category',
                                                        style: TextStyle(
                                                          color: Colors.black,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                        ),
                                                      ),
                                                    ),
                                                    Flexible(
                                                      child: Icon(
                                                        Icons
                                                            .keyboard_arrow_down_rounded,
                                                        color: kLightGrey,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Flexible(
                                                flex: 2,
                                                child: (snapshot.hasData)
                                                    ? ListView.separated(
                                                        scrollDirection:
                                                            Axis.horizontal,
                                                        itemCount: snapshot
                                                            .data.length,
                                                        itemBuilder:
                                                            (context, index) {
                                                          return ChoiceChip(
                                                            label: Text(snapshot
                                                                .data[index]
                                                                .name),
                                                            pressElevation: 0.0,
                                                            selectedColor:
                                                                kSecondary,
                                                            labelStyle:
                                                                const TextStyle(
                                                                    color: Colors
                                                                        .black),
                                                            selected: int.parse(
                                                                    selectedMainCategory
                                                                        .toString()) ==
                                                                snapshot
                                                                    .data[index]
                                                                    .id,
                                                            onSelected:
                                                                (state) {
                                                              setState(() {
                                                                selectedMainCategory =
                                                                    snapshot
                                                                        .data[
                                                                            index]
                                                                        .id
                                                                        .toString();

                                                                selectedMainCategoryName =
                                                                    snapshot
                                                                        .data[
                                                                            index]
                                                                        .name
                                                                        .toString();
                                                              });
                                                            },
                                                          );
                                                        },
                                                        separatorBuilder:
                                                            (context, index) {
                                                          return const SizedBox(
                                                              width: 8.0);
                                                        },
                                                      )
                                                    : const Center(
                                                        child: AspectRatio(
                                                          aspectRatio: 1,
                                                          child: Padding(
                                                            padding:
                                                                EdgeInsets.all(
                                                                    3.0),
                                                            child: CircularProgressIndicator(
                                                                color:
                                                                    kSecondary),
                                                          ),
                                                        ),
                                                      ),
                                              ),
                                              const Flexible(
                                                child: Divider(
                                                  thickness: 1.3,
                                                  indent: 8.0,
                                                  endIndent: 8.0,
                                                ),
                                              ),
                                            ],
                                          ),
                                        );
                                      },
                                    ),
                                  ),
                                  Expanded(
                                    flex: 3,
                                    child: FutureBuilder<List<OrsCategory>>(
                                      future: getCategory(),
                                      builder: (BuildContext context,
                                          AsyncSnapshot snapshot) {
                                        return Padding(
                                          padding: const EdgeInsets.symmetric(
                                            vertical: 4.0,
                                            horizontal: 8.0,
                                          ),
                                          child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceEvenly,
                                            children: [
                                              Flexible(
                                                child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: const [
                                                    Flexible(
                                                      child: Text(
                                                        'Category',
                                                        style: TextStyle(
                                                          color: Colors.black,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                        ),
                                                      ),
                                                    ),
                                                    Flexible(
                                                      child: Icon(
                                                        Icons
                                                            .keyboard_arrow_down_rounded,
                                                        color: kLightGrey,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Flexible(
                                                flex: 2,
                                                child: (snapshot.hasData)
                                                    ? ListView.separated(
                                                        scrollDirection:
                                                            Axis.horizontal,
                                                        itemCount: snapshot
                                                            .data.length,
                                                        itemBuilder:
                                                            (context, index) {
                                                          return ChoiceChip(
                                                            label: Text(snapshot
                                                                .data[index]
                                                                .name),
                                                            pressElevation: 0.0,
                                                            selectedColor:
                                                                kSecondary,
                                                            labelStyle:
                                                                const TextStyle(
                                                                    color: Colors
                                                                        .black),
                                                            selected: int.parse(
                                                                    selectedCategory
                                                                        .toString()) ==
                                                                snapshot
                                                                    .data[index]
                                                                    .id,
                                                            onSelected:
                                                                (state) {
                                                              setState(() {
                                                                selectedCategory =
                                                                    snapshot
                                                                        .data[
                                                                            index]
                                                                        .id
                                                                        .toString();

                                                                selectedCategoryName =
                                                                    snapshot
                                                                        .data[
                                                                            index]
                                                                        .name
                                                                        .toString();
                                                              });
                                                            },
                                                          );
                                                        },
                                                        separatorBuilder:
                                                            (context, index) {
                                                          return const SizedBox(
                                                              width: 8.0);
                                                        },
                                                      )
                                                    : const Center(
                                                        child: AspectRatio(
                                                          aspectRatio: 1,
                                                          child: Padding(
                                                            padding:
                                                                EdgeInsets.all(
                                                                    3.0),
                                                            child: CircularProgressIndicator(
                                                                color:
                                                                    kSecondary),
                                                          ),
                                                        ),
                                                      ),
                                              ),
                                              const Flexible(
                                                child: Divider(
                                                  thickness: 1.3,
                                                  indent: 8.0,
                                                  endIndent: 8.0,
                                                ),
                                              ),
                                            ],
                                          ),
                                        );
                                      },
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        )
                      : Expanded(
                          flex: 1,
                          child: Padding(
                            padding:
                                const EdgeInsets.only(left: 30.0, top: 5.0),
                            child: GestureDetector(
                              onTap: () {
                                setState(() {
                                  filterActive = !filterActive;
                                });
                              },
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: const [
                                  Flexible(
                                    child: Icon(
                                      Icons.filter_list_rounded,
                                      color: kSecondary,
                                    ),
                                  ),
                                  Flexible(child: SizedBox(width: 3.0)),
                                  Flexible(
                                    child: Text(
                                      "FILTER",
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                  Expanded(
                    flex: (filterActive) ? 6 : 12,
                    child: PagedListView<int, OrsAds>(
                      pagingController: pagingController,
                      builderDelegate: PagedChildBuilderDelegate<OrsAds>(
                        itemBuilder: (context, data, index) {
                          return Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 12.0, vertical: 5.0),
                            child: AdsCard(
                              ad: data,
                              isEditableAd: false,
                              isDetails: false,
                              favIds: widget.favIds,
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    super.dispose();
    pagingController.dispose();
  }
}
