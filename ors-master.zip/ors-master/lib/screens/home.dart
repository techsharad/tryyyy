import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:ors/api/web_api.dart';
import 'package:ors/colour_schemes.dart';
import 'package:ors/models/data_model.dart';
import 'package:ors/models/user_model.dart';
import 'package:ors/providers/location_provider.dart';
import 'package:ors/providers/user_provider.dart';
import 'package:ors/routes.dart';
import 'package:ors/screens/add_listing.dart';
import 'package:ors/screens/favourites.dart';
import 'package:ors/screens/my_profile.dart';
import 'package:ors/screens/search.dart';
import 'package:ors/screens/search_results.dart';
import 'package:ors/screens/welcome.dart';
import 'package:ors/test.dart';
import 'package:ors/widgets/custom_dropdown.dart';
import 'package:ors/widgets/homescreen_buttons.dart';
import 'package:persistent_bottom_nav_bar/persistent-tab-view.dart';
import 'package:provider/provider.dart';

class HomeScreen extends StatefulWidget {
  final OrsUser? user;

  const HomeScreen({
    Key? key,
    required this.user,
  }) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  PersistentTabController tabController =
      PersistentTabController(initialIndex: 0);

  @override
  Widget build(BuildContext context) {
    if (widget.user != null) {
      Provider.of<OrsUserProvider>(context).setUserAtRunTime = widget.user;
    }

    OrsUser? orsUser = Provider.of<OrsUserProvider>(context).user;

    List<Widget> _navBarView = [
      const LandingPage(),
      (orsUser == null) ? const Welcome() : const Favourites(),
      (orsUser == null) ? const Welcome() : const AddListing(),
      // const LandingPage(), // const SearchPage(),
      (orsUser == null) ? const Welcome() : const MyProfile(),
    ];

    List<PersistentBottomNavBarItem> _navBarItems = [
      PersistentBottomNavBarItem(
        icon: const Icon(Icons.home_rounded),
        activeColorPrimary: kPrimary,
        inactiveColorPrimary: Colors.grey,
        routeAndNavigatorSettings: const RouteAndNavigatorSettings(
            onGenerateRoute: Routes.generateRoute),
      ),
      PersistentBottomNavBarItem(
        icon: const Icon(Icons.favorite_rounded),
        activeColorPrimary: kPrimary,
        inactiveColorPrimary: Colors.grey,
      ),
      /*PersistentBottomNavBarItem(
        icon: const Icon(Icons.add_rounded),
        activeColorPrimary: kSecondary,
        activeColorSecondary: Colors.white,
        onPressed: (newContext) => Fluttertoast.showToast(
          msg: "Coming soon!",
          gravity: ToastGravity.BOTTOM,
          backgroundColor: kPrimary,
          textColor: Colors.white,
        ),
        routeAndNavigatorSettings: const RouteAndNavigatorSettings(
            onGenerateRoute: Routes.generateRoute),
      ),*/
      /*PersistentBottomNavBarItem(
        icon: const Icon(Icons.search_rounded),
        activeColorPrimary: kPrimary,
        inactiveColorPrimary: Colors.grey,
      ),*/
      PersistentBottomNavBarItem(
        icon: const Icon(Icons.add_rounded),
        activeColorPrimary: kPrimary,
        inactiveColorPrimary: Colors.grey,
        onPressed: (context) => Fluttertoast.showToast(
          msg: "Coming soon!",
          gravity: ToastGravity.BOTTOM,
          backgroundColor: kPrimary,
          textColor: Colors.white,
        ),
      ),
      PersistentBottomNavBarItem(
        icon: const Icon(Icons.person_outline_rounded),
        activeColorPrimary: kPrimary,
        inactiveColorPrimary: Colors.grey,
      ),
    ];

    return Consumer<OrsUserProvider>(
      builder: (context, data, w) {
        return PersistentTabView(
          context,
          controller: tabController,
          backgroundColor: Colors.white,
          screenTransitionAnimation: const ScreenTransitionAnimation(
            animateTabTransition: true,
            curve: Curves.ease,
            duration: Duration(milliseconds: 500),
          ),
          confineInSafeArea: true,
          handleAndroidBackButtonPress: true,
          resizeToAvoidBottomInset: false,
          stateManagement: false,
          navBarStyle: NavBarStyle.style13,
          floatingActionButton: Container(),
          screens: _navBarView,
          items: _navBarItems,
        );
      },
    );
  }
}

class LandingPage extends StatefulWidget {
  const LandingPage({Key? key}) : super(key: key);

  @override
  _LandingPageState createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> {
  Future<List<OrsCategory>> getCategory() => WebApi().getCategoryList('1');

  var selectedCategory;
  var selectedLocation;

  @override
  Widget build(BuildContext context) {
    WebApi webApi = WebApi();

    OrsUser? user = Provider.of<OrsUserProvider>(context, listen: false).user;

    List<Map> buildItems(AsyncSnapshot snapshot) {
      List<Map<String, dynamic>> items = [];

      for (var i = 0; i < snapshot.data.length; i++) {
        items.add(
          {
            'id': i,
            'value': snapshot.data[i].id,
            'child': snapshot.data[i].name,
          },
        );
      }
      return items;
    }

    OverlayEntry entry = OverlayEntry(
      builder: (context) {
        return Container(
          height: double.maxFinite,
          width: double.maxFinite,
          color: Colors.black.withOpacity(0.2),
          child: const Center(
            child: SizedBox(
              height: 30.0,
              width: 30.0,
              child: CircularProgressIndicator(color: kPrimary),
            ),
          ),
        );
      },
    );

    List<int> fetchAdIds(List<FavAd> inp) {
      List<int> temp = [];

      for (var i = 0; i < inp.length; i++) {
        temp.add(inp[i].ad.id);
      }

      return temp;
    }

    return Consumer<LocationProvider>(
      builder: (context, locData, w) {
        return Scaffold(
          resizeToAvoidBottomInset: false,
          backgroundColor: Colors.grey[200],
          body: SafeArea(
            child: Column(
              children: [
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 30.0,
                      right: 30.0,
                      top: 40.0,
                      bottom: 20.0,
                    ),
                    child: Image.asset('assets/images/replica 1.png'),
                  ),
                ),
                Expanded(
                  flex: 2,
                  child: Container(
                    height: double.maxFinite,
                    width: double.maxFinite,
                    margin: const EdgeInsets.symmetric(
                        horizontal: 25.0, vertical: 10.0),
                    padding: const EdgeInsets.symmetric(
                        vertical: 10.0, horizontal: 15.0),
                    decoration: BoxDecoration(
                      color: kPrimary,
                      borderRadius: BorderRadius.circular(15.0),
                    ),
                    child: Column(
                      children: [
                        const Expanded(
                          flex: 1,
                          child: Center(
                            child: Text(
                              "Find Road Service Near You With Ease",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                        const Expanded(
                          flex: 3,
                          child: Center(
                            child: Text(
                              "Stop worrying on the road, have your backup plan ready. Fast & Reliable help for your emergency.",
                              textAlign: TextAlign.center,
                              style: TextStyle(color: Colors.white),
                            ),
                          ),
                        ),
                        Expanded(
                          flex: 3,
                          child: Container(
                            width: double.maxFinite,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(10.0),
                            ),
                            margin:
                                const EdgeInsets.only(bottom: 4.0, top: 12.0),
                            child: FutureBuilder<List<OrsCategory>>(
                              future: getCategory(),
                              builder: (context, snapshot) {
                                if (snapshot.hasData) {
                                  return MyDropdown(
                                    title: "Choose Category",
                                    titleColor: kPrimary,
                                    icon: const Icon(
                                      Icons.arrow_drop_down_rounded,
                                      color: kSecondary,
                                    ),
                                    value: selectedCategory,
                                    items: buildItems(snapshot),
                                    isAddressField: false,
                                    onChanged: (value) {
                                      setState(() {
                                        selectedCategory = value;
                                      });
                                    },
                                  );
                                } else {
                                  return Align(
                                    alignment: Alignment.centerLeft,
                                    child: AspectRatio(
                                      aspectRatio: 1,
                                      child: Padding(
                                        padding: const EdgeInsets.all(10.0),
                                        child: CircularProgressIndicator(
                                          color: kSecondary.withOpacity(0.6),
                                        ),
                                      ),
                                    ),
                                  );
                                }
                              },
                            ),
                          ),
                        ),
                        Expanded(
                          flex: 3,
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(10.0),
                            ),
                            margin:
                                const EdgeInsets.only(bottom: 12.0, top: 4.0),
                            child: MyDropdown(
                              title: "Location",
                              titleColor: kPrimary,
                              icon: const Icon(
                                Icons.location_on_rounded,
                                color: kSecondary,
                                size: 16.0,
                              ),
                              value: selectedLocation,
                              onChanged: (value) {
                                setState(() {
                                  selectedLocation = value;
                                });
                              },
                              isAddressField: true,
                            ),
                          ),
                        ),
                        Expanded(
                          flex: 2,
                          child: TextButton(
                            onPressed: () async {
                              if (selectedCategory != null &&
                                  selectedLocation != null) {
                                if (selectedLocation.city == null) {
                                  Fluttertoast.showToast(
                                    msg:
                                        "Please select a city from the list, you've selected a state/country",
                                    gravity: ToastGravity.BOTTOM,
                                    backgroundColor: kPrimary,
                                    textColor: Colors.white,
                                  );
                                } else {
                                  List<int> resp = [];

                                  Overlay.of(context)!.insert(entry);

                                  if (user != null) {
                                    resp = fetchAdIds(
                                        await webApi.getFavouritesList(
                                            user.userId.toString()));
                                  }

                                  entry.remove();

                                  pushNewScreen(
                                    context,
                                    screen: SearchResults(
                                      selectedCategory:
                                          selectedCategory[0].toString(),
                                      selectedCategoryName:
                                          selectedCategory[1].toString(),
                                      selectedMainCategory: '1',
                                      selectedMainCategoryName:
                                          'Truck / Trailer',
                                      selectedPlace: selectedLocation as Places,
                                      favIds: resp,
                                    ),
                                    withNavBar: false,
                                    pageTransitionAnimation:
                                        PageTransitionAnimation.fade,
                                  );
                                }
                              } else {
                                Fluttertoast.showToast(
                                  msg:
                                      "Please choose a category & select a location from list!",
                                  gravity: ToastGravity.BOTTOM,
                                  backgroundColor: kPrimary,
                                  textColor: Colors.white,
                                );
                              }
                            },
                            style: ButtonStyle(
                              enableFeedback: true,
                              shape: MaterialStateProperty.all(
                                  RoundedRectangleBorder(
                                      borderRadius:
                                          BorderRadius.circular(10.0))),
                              elevation: MaterialStateProperty.all(5.0),
                              backgroundColor:
                                  MaterialStateProperty.all(kSecondary),
                              padding: MaterialStateProperty.all(
                                EdgeInsets.symmetric(
                                    horizontal:
                                        MediaQuery.of(context).size.width *
                                            0.15),
                              ),
                            ),
                            child: const Text(
                              "Search",
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const Expanded(
                  flex: 2,
                  child: HomeButtons(),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
