import 'package:flutter/material.dart';
import 'package:ors/colour_schemes.dart';
import 'package:ors/models/data_model.dart';
import 'package:ors/widgets/ads_card.dart';
import 'package:ors/widgets/drawer.dart';

class AdsDetails extends StatefulWidget {
  final OrsAds ad;
  final bool isEditableAd;
  final String? favID;
  final ValueChanged? onDelete;
  final List<int> favIds;

  const AdsDetails({
    Key? key,
    required this.ad,
    required this.isEditableAd,
    this.favID,
    this.onDelete,
    required this.favIds,
  }) : super(key: key);

  @override
  _AdsDetailsState createState() => _AdsDetailsState();
}

class _AdsDetailsState extends State<AdsDetails> {
  GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.grey[200],
      endDrawer: const GlobalDrawer(),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: Stack(
                children: [
                  SizedBox(
                    height: double.maxFinite,
                    width: double.maxFinite,
                    child: Image.asset(
                      'assets/images/3 3.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                  const Align(
                    alignment: Alignment.topLeft,
                    child: BackButton(color: Colors.white),
                  ),
                  Align(
                    alignment: Alignment.topRight,
                    child: IconButton(
                      onPressed: () =>
                          scaffoldKey.currentState!.openEndDrawer(),
                      color: Colors.white,
                      iconSize: 28.0,
                      icon: const ImageIcon(
                          AssetImage('assets/icon/feather_bar-chart-2.png')),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    widget.ad.company,
                    textScaleFactor: 1.2,
                    style: const TextStyle(
                      color: kPrimary,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 10.0),
                  Container(
                    height: 6.0,
                    width: 64.0,
                    decoration: BoxDecoration(
                      color: kSecondary,
                      borderRadius: BorderRadius.circular(50.0),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              flex: 4,
              child: Card(
                margin: EdgeInsets.zero,
                elevation: 10.0,
                shape: const RoundedRectangleBorder(
                  borderRadius:
                      BorderRadius.vertical(top: Radius.circular(30.0)),
                ),
                child: SizedBox.expand(
                  child: Column(
                    children: [
                      Expanded(
                        child: GestureDetector(
                          onVerticalDragDown: (details) =>
                              Navigator.of(context).pop(),
                          child: Center(
                            child: Container(
                              height: 6.0,
                              width: 50.0,
                              decoration: BoxDecoration(
                                color: kPrimary.withOpacity(0.7),
                                borderRadius: BorderRadius.circular(50.0),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        flex: 11,
                        child: SingleChildScrollView(
                          child: AdsCard(
                            ad: widget.ad,
                            favIds: widget.favIds,
                            isDetails: true,
                            isEditableAd: widget.isEditableAd,
                            favID: widget.favID,
                            onDelete: (data) => Navigator.of(context).pop(),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
