import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:image_picker/image_picker.dart';
import 'package:ors/api/web_api.dart';
import 'package:ors/colour_schemes.dart';
import 'package:ors/main.dart';
import 'package:ors/models/data_model.dart';
import 'package:ors/models/user_model.dart';
import 'package:ors/providers/auth_provider.dart';
import 'package:ors/providers/user_provider.dart';
import 'package:ors/services/user_prefs.dart';
import 'package:ors/widgets/custom_dropdown.dart';
import 'package:ors/widgets/drawer.dart';
import 'package:persistent_bottom_nav_bar/persistent-tab-view.dart';
import 'package:provider/provider.dart';

class MyProfile extends StatefulWidget {
  const MyProfile({Key? key}) : super(key: key);

  @override
  _MyProfileState createState() => _MyProfileState();
}

class _MyProfileState extends State<MyProfile> {
  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();

  TextEditingController nameController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  TextEditingController emailController = TextEditingController();

  final ImagePicker _picker = ImagePicker();

  Places? selectedLocation;

  bool isOnEditMode = false;

  UserPreferences prefs = UserPreferences();
  WebApi webApi = WebApi();

  Future<void> deleteAccount(OrsUser user) async {
    if (!await webApi.deleteAccount(user.phone)) {
      Fluttertoast.showToast(
        msg: "Please try again!",
        gravity: ToastGravity.BOTTOM,
        backgroundColor: kPrimary,
        textColor: Colors.white,
      );

      return;
    }

    prefs.removeUser();

    Provider.of<OrsUserProvider>(context, listen: false).setUser(null);

    Fluttertoast.showToast(
      msg: "Account deleted successfully",
      gravity: ToastGravity.BOTTOM,
      backgroundColor: kPrimary,
      textColor: Colors.white,
    );

    ORS.restartApp(context);
  }

  @override
  Widget build(BuildContext context) {
    AuthProvider auth = Provider.of<AuthProvider>(context, listen: false);

    OverlayEntry overlayEntry = OverlayEntry(
      builder: (context) {
        return Container(
          height: double.maxFinite,
          width: double.maxFinite,
          color: Colors.black.withOpacity(0.2),
          child: const Center(
            child: SizedBox(
              height: 30.0,
              width: 30.0,
              child: CircularProgressIndicator(color: kPrimary),
            ),
          ),
        );
      },
    );

    return Consumer<OrsUserProvider>(
      builder: (context, userData, w) {
        OrsUser user = userData.user as OrsUser;

        String source = 'http://onlineroadservices.com/${user.imgPath}';

        if (nameController.text.isEmpty &&
            phoneController.text.isEmpty &&
            emailController.text.isEmpty) {
          nameController.text = user.name;
          phoneController.text = user.phone;
          if (user.email != null && user.email != "null") {
            emailController.text = user.email.toString();
          }
        }
        // if (user.company != null && user.company != "null") {
        //   companyController.text = user.company.toString();
        // }

        return Scaffold(
          key: scaffoldKey,
          resizeToAvoidBottomInset: false,
          backgroundColor: Colors.grey[200],
          endDrawer: const GlobalDrawer(),
          body: SafeArea(
            child: Column(
              children: [
                Expanded(
                  flex: 2,
                  child: Stack(
                    children: [
                      Column(
                        children: [
                          Expanded(
                            flex: 4,
                            child: Image.asset(
                              'assets/images/3 3.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                          Expanded(
                            flex: 2,
                            child: Container(),
                          ),
                        ],
                      ),
                      Align(
                        alignment: Alignment.bottomCenter,
                        child: Container(
                          height: MediaQuery.of(context).size.width * 0.32,
                          width: MediaQuery.of(context).size.width * 0.32,
                          padding: const EdgeInsets.all(5.0),
                          decoration: const BoxDecoration(
                            color: Colors.white,
                            shape: BoxShape.circle,
                          ),
                          child: Stack(
                            fit: StackFit.expand,
                            children: [
                              CircleAvatar(
                                backgroundColor: Colors.grey[200],
                                backgroundImage: NetworkImage(source),
                                onBackgroundImageError: (obj, trace) {
                                  setState(() {
                                    source =
                                        "https://www.kindpng.com/picc/m/269-2697881_computer-icons-user-clip-art-transparent-png-icon.png";
                                  });
                                },
                              ),
                              (isOnEditMode)
                                  ? GestureDetector(
                                      onTap: () async {
                                        XFile? image;

                                        try {
                                          image = await _picker.pickImage(
                                            source: ImageSource.gallery,
                                          );
                                        } catch (e) {
                                          Fluttertoast.showToast(
                                            msg: e.toString(),
                                            gravity: ToastGravity.BOTTOM,
                                            backgroundColor: kPrimary,
                                            textColor: Colors.white,
                                          );
                                        }

                                        if (image != null) {
                                          Overlay.of(context)!
                                              .insert(overlayEntry);

                                          bool resp = await auth.profilePic(
                                            user.userId.toString(),
                                            image.path,
                                          );

                                          overlayEntry.remove();

                                          if (resp) {
                                            Fluttertoast.showToast(
                                              msg:
                                                  "Profile Picture updated successfully",
                                              gravity: ToastGravity.BOTTOM,
                                              backgroundColor: kPrimary,
                                              textColor: Colors.white,
                                            );

                                            ORS.restartApp(context);
                                          } else {
                                            Fluttertoast.showToast(
                                              msg: "Please try again later!",
                                              gravity: ToastGravity.BOTTOM,
                                              backgroundColor: kPrimary,
                                              textColor: Colors.white,
                                            );
                                          }
                                        }
                                      },
                                      child: Container(
                                        height: double.maxFinite,
                                        width: double.maxFinite,
                                        decoration: BoxDecoration(
                                          color: Colors.black.withOpacity(0.5),
                                          shape: BoxShape.circle,
                                        ),
                                        child: const Center(
                                          child: Icon(
                                            Icons.camera_alt_rounded,
                                            color: Colors.white,
                                          ),
                                        ),
                                      ),
                                    )
                                  : Container(),
                            ],
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.topRight,
                        child: IconButton(
                          onPressed: () =>
                              scaffoldKey.currentState!.openEndDrawer(),
                          color: Colors.white,
                          iconSize: 28.0,
                          icon: const ImageIcon(AssetImage(
                              'assets/icon/feather_bar-chart-2.png')),
                        ),
                      ),
                    ],
                  ),
                ),
                (isOnEditMode)
                    ? Expanded(
                        flex: 5,
                        child: SingleChildScrollView(
                          padding: const EdgeInsets.all(15.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Align(
                                alignment: Alignment.centerRight,
                                child: TextButton(
                                  onPressed: () {
                                    setState(() {
                                      isOnEditMode = false;
                                    });
                                  },
                                  child: const Text(
                                    "Cancel edit",
                                    style: TextStyle(
                                      color: kSecondary,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(
                                  height: MediaQuery.of(context).size.height *
                                      0.05),
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Text(
                                  "Address *",
                                  style: TextStyle(
                                    color: Colors.grey[600],
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 12.0),
                              Container(
                                decoration: BoxDecoration(
                                  color: Colors.transparent,
                                  borderRadius: BorderRadius.circular(10.0),
                                  border: Border.all(color: Colors.grey),
                                ),
                                constraints: BoxConstraints.tight(
                                    const Size(double.maxFinite, 60)),
                                margin: const EdgeInsets.only(
                                    bottom: 12.0, top: 4.0),
                                child: MyDropdown(
                                  title: "Location",
                                  titleColor: kPrimary,
                                  icon: const Icon(
                                    Icons.location_on_rounded,
                                    color: Colors.transparent,
                                    size: 16.0,
                                  ),
                                  value: selectedLocation,
                                  onChanged: (value) {
                                    setState(() {
                                      selectedLocation = value;
                                    });
                                  },
                                  isAddressField: true,
                                ),
                              ),
                              const SizedBox(height: 20.0),
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Text(
                                  "Name *",
                                  style: TextStyle(
                                    color: Colors.grey[600],
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 12.0),
                              TextFormField(
                                controller: nameController,
                                cursorRadius: const Radius.circular(50.0),
                                enableInteractiveSelection: false,
                                enableSuggestions: false,
                                keyboardType: TextInputType.name,
                                maxLines: 1,
                                style: const TextStyle(
                                  color: kPrimary,
                                  fontWeight: FontWeight.w500,
                                ),
                                decoration: InputDecoration(
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                    borderSide: const BorderSide(
                                      color: Colors.grey,
                                      width: 1.2,
                                    ),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                    borderSide: const BorderSide(
                                      color: kPrimary,
                                      width: 1.2,
                                    ),
                                  ),
                                  counterText: '',
                                ),
                              ),
                              const SizedBox(height: 20.0),
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Text(
                                  "Phone number *",
                                  style: TextStyle(
                                    color: Colors.grey[600],
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 12.0),
                              TextFormField(
                                controller: phoneController,
                                cursorRadius: const Radius.circular(50.0),
                                enableInteractiveSelection: false,
                                enableSuggestions: false,
                                keyboardType: TextInputType.phone,
                                maxLength: 10,
                                maxLines: 1,
                                style: const TextStyle(
                                  color: kPrimary,
                                  fontWeight: FontWeight.w500,
                                ),
                                decoration: InputDecoration(
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                    borderSide: const BorderSide(
                                      color: Colors.grey,
                                      width: 1.2,
                                    ),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                    borderSide: const BorderSide(
                                      color: kPrimary,
                                      width: 1.2,
                                    ),
                                  ),
                                  counterText: '',
                                ),
                              ),
                              const SizedBox(height: 20.0),
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Text(
                                  "E-mail address *",
                                  style: TextStyle(
                                    color: Colors.grey[600],
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 12.0),
                              TextFormField(
                                controller: emailController,
                                cursorRadius: const Radius.circular(50.0),
                                enableInteractiveSelection: false,
                                enableSuggestions: false,
                                keyboardType: TextInputType.emailAddress,
                                maxLines: 1,
                                style: const TextStyle(
                                  color: kPrimary,
                                  fontWeight: FontWeight.w500,
                                ),
                                decoration: InputDecoration(
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                    borderSide: const BorderSide(
                                      color: Colors.grey,
                                      width: 1.2,
                                    ),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                    borderSide: const BorderSide(
                                      color: kPrimary,
                                      width: 1.2,
                                    ),
                                  ),
                                  counterText: '',
                                ),
                              ),
                              SizedBox(
                                  height: MediaQuery.of(context).size.height *
                                      0.05),
                              MaterialButton(
                                onPressed: () async {
                                  if (nameController.text.isNotEmpty &&
                                      phoneController.text.isNotEmpty &&
                                      emailController.text.isNotEmpty &&
                                      selectedLocation != null) {
                                    Overlay.of(context)!.insert(overlayEntry);

                                    Map loginUser = await auth.updateProfile(
                                      user.userId.toString(),
                                      nameController.text,
                                      emailController.text,
                                      phoneController.text,
                                      selectedLocation as Places,
                                    );

                                    overlayEntry.remove();

                                    if (loginUser['status']) {
                                      Provider.of<OrsUserProvider>(context,
                                              listen: false)
                                          .setUser(loginUser['user']);

                                      setState(() {
                                        isOnEditMode = false;
                                      });

                                      Fluttertoast.showToast(
                                        msg: "Update successful",
                                        gravity: ToastGravity.BOTTOM,
                                        backgroundColor: kPrimary,
                                        textColor: Colors.white,
                                      );

                                      ORS.restartApp(context);
                                    } else {
                                      Fluttertoast.showToast(
                                        msg: "Unable to update profile",
                                        gravity: ToastGravity.BOTTOM,
                                        backgroundColor: kPrimary,
                                        textColor: Colors.white,
                                      );
                                    }
                                  } else {
                                    Fluttertoast.showToast(
                                      msg: "Please fill-up all the fields!",
                                      gravity: ToastGravity.BOTTOM,
                                      backgroundColor: kPrimary,
                                      textColor: Colors.white,
                                    );
                                  }
                                },
                                color: kPrimary,
                                elevation: 0.0,
                                height: 40.0,
                                minWidth:
                                    MediaQuery.of(context).size.width * 0.45,
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10.0)),
                                child: const Text(
                                  "Update",
                                  style: TextStyle(color: Colors.white),
                                ),
                              ),
                              SizedBox(
                                  height: (MediaQuery.of(context)
                                              .viewInsets
                                              .bottom ==
                                          0.0)
                                      ? 15.0
                                      : MediaQuery.of(context)
                                          .viewInsets
                                          .bottom),
                            ],
                          ),
                        ),
                      )
                    : Expanded(
                        flex: 5,
                        child: SingleChildScrollView(
                          padding: const EdgeInsets.all(15.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Stack(
                                children: [
                                  Center(
                                    child: Text(
                                      user.name,
                                      textScaleFactor: 1.5,
                                      style: const TextStyle(
                                        color: kPrimary,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ),
                                  Align(
                                    alignment: Alignment.centerRight,
                                    child: GestureDetector(
                                      onTap: () {
                                        setState(() {
                                          isOnEditMode = !isOnEditMode;
                                        });
                                      },
                                      child: const Padding(
                                        padding: EdgeInsets.only(right: 10.0),
                                        child: Icon(
                                          Icons.edit_rounded,
                                          color: kSecondary,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(
                                  height: MediaQuery.of(context).size.height *
                                      0.05),
                              const Text(
                                "Phone Number",
                                textScaleFactor: 1.15,
                                style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              SizedBox(
                                  height: MediaQuery.of(context).size.height *
                                      0.02),
                              Container(
                                width: double.maxFinite,
                                decoration: BoxDecoration(
                                  border: Border.all(
                                    color: Colors.grey.withOpacity(0.5),
                                    width: 1.5,
                                  ),
                                  borderRadius: BorderRadius.circular(15.0),
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(15.0),
                                  child: Text(
                                    user.phone,
                                    textScaleFactor: 1.15,
                                    style: const TextStyle(
                                      color: kPrimary,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(
                                  height: MediaQuery.of(context).size.height *
                                      0.03),
                              const Text(
                                "Email",
                                textScaleFactor: 1.15,
                                style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              SizedBox(
                                  height: MediaQuery.of(context).size.height *
                                      0.02),
                              Container(
                                width: double.maxFinite,
                                decoration: BoxDecoration(
                                  border: Border.all(
                                    color: Colors.grey.withOpacity(0.5),
                                    width: 1.5,
                                  ),
                                  borderRadius: BorderRadius.circular(15.0),
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(15.0),
                                  child: Text(
                                    (user.email != null && user.email != "null")
                                        ? user.email.toString()
                                        : "{ E-mail address not added yet }",
                                    textScaleFactor: 1.15,
                                    style: const TextStyle(
                                      color: kPrimary,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ),
                              ),
                              /*SizedBox(
                                  height: MediaQuery.of(context).size.height *
                                      0.03),
                              const Text(
                                "Company",
                                textScaleFactor: 1.15,
                                style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              SizedBox(
                                  height: MediaQuery.of(context).size.height *
                                      0.02),
                              Container(
                                width: double.maxFinite,
                                decoration: BoxDecoration(
                                  border: Border.all(
                                    color: Colors.grey.withOpacity(0.5),
                                    width: 1.5,
                                  ),
                                  borderRadius: BorderRadius.circular(15.0),
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(15.0),
                                  child: Text(
                                    (user.company != null &&
                                            user.company != "null")
                                        ? user.company.toString()
                                        : "{ company info not added }",
                                    textScaleFactor: 1.15,
                                    style: const TextStyle(
                                      color: kPrimary,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ),
                              ),*/
                              SizedBox(
                                  height: MediaQuery.of(context).size.height *
                                      0.03),
                              const Text(
                                "Address",
                                textScaleFactor: 1.15,
                                style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              SizedBox(
                                  height: MediaQuery.of(context).size.height *
                                      0.02),
                              Container(
                                width: double.maxFinite,
                                decoration: BoxDecoration(
                                  border: Border.all(
                                    color: Colors.grey.withOpacity(0.5),
                                    width: 1.5,
                                  ),
                                  borderRadius: BorderRadius.circular(15.0),
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(15.0),
                                  child: Text(
                                    (user.address != null &&
                                            user.address != "null")
                                        ? user.address.toString()
                                        : "{ address info not added }",
                                    textScaleFactor: 1.15,
                                    style: const TextStyle(
                                      color: kPrimary,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ),
                              ),
                              Center(
                                child: Padding(
                                  padding: const EdgeInsets.all(12.0),
                                  child: MaterialButton(
                                    onPressed: () async {
                                      Overlay.of(context)!.insert(overlayEntry);

                                      await deleteAccount(user);

                                      overlayEntry.remove();
                                    },
                                    color: Colors.amber,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8.0),
                                    ),
                                    child: const Text("Delete Account"),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
              ],
            ),
          ),
        );
      },
    );
  }
}
