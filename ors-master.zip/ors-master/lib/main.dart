import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

import 'package:ors/models/user_model.dart';
import 'package:ors/providers/auth_provider.dart';
import 'package:ors/providers/location_provider.dart';
import 'package:ors/providers/user_provider.dart';
import 'package:ors/routes.dart';
import 'package:ors/screens/home.dart';
import 'package:ors/services/user_prefs.dart';
import 'package:provider/provider.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  if (Platform.isAndroid) {
    await AndroidInAppWebViewController.setWebContentsDebuggingEnabled(true);
  }

  runApp(const ORS());
}

class ORS extends StatefulWidget {
  const ORS({Key? key}) : super(key: key);

  static void restartApp(BuildContext context) =>
      context.findAncestorStateOfType<_ORSState>()!.restartApp();

  @override
  _ORSState createState() => _ORSState();
}

class _ORSState extends State<ORS> {
  Key key = UniqueKey();

  void restartApp() => setState(() {
        key = UniqueKey();
      });

  Future<dynamic> getUserData() => UserPreferences().getUser();

  @override
  Widget build(BuildContext context) {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);

    return KeyedSubtree(
      key: key,
      child: MultiProvider(
        providers: [
          ChangeNotifierProvider(create: (_) => AuthProvider()),
          ChangeNotifierProvider(create: (_) => OrsUserProvider()),
          ChangeNotifierProvider(create: (_) => LocationProvider()),
        ],
        child: FutureBuilder<dynamic>(
          future: getUserData(),
          builder: (context, snapshot) {
            return MaterialApp(
              debugShowCheckedModeBanner: false,
              onGenerateRoute: Routes.generateRoute,
              theme: ThemeData(
                primarySwatch: Colors.teal,
                fontFamily: 'Inter',
              ),
              home: HomeScreen(user: snapshot.data),
            );
          },
        ),
      ),
    );
  }
}
