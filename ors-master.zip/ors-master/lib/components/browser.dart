import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

class OpenWebsite extends ChromeSafariBrowser {
  @override
  void onOpened() {
    debugPrint("Website opened");
  }

  @override
  void onCompletedInitialLoad() {
    debugPrint("Website initial load completed");
  }

  @override
  void onClosed() {
    debugPrint("Website closed");
  }
}
