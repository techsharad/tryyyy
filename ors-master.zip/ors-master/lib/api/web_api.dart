import 'dart:developer';

import 'package:ors/api/http_handler.dart';
import 'package:ors/models/data_model.dart';

class WebApi {
  final String _baseUrl = 'www.onlineroadservices.com';
  final String _apiKey = 'ak8nui95ml00a12rw5in55gs';

  final String _otpPath = 'api/sendotpviaphone';
  final String _changePasswordPath = 'api/changepswd';
  final String _getMainCategoryPath = 'api/getmaincategorylist';
  final String _getCategoryPath = 'api/getcategorylistbymaincategory';
  final String _getSearchResultPath = 'api/searchads';
  final String _getFavouritesPath = 'api/getfavbyuser';
  final String _setFavouritesPath = 'api/addfavad';
  final String _deleteFavouritePath = 'api/deletefavad';
  final String _arrangeCallbackPath = 'api/arrangecallback';
  final String _shareAdPath = 'api/shareadinfo';
  final String _verifyPhonePath = 'api/checkbyphone';
  final String _deleteAccountPath = 'api/delete/user';

  HandleHTTP httpHandler = HandleHTTP();

  Future<bool> deleteAccount(String phone) async {
    final url = Uri.http(
      _baseUrl,
      _deleteAccountPath,
      {
        'apikey': _apiKey,
        'phone': phone,
      },
    );

    final response = await httpHandler.getData(url);

    log(response.toString());

    if (response['responseMessage'] == "SUCCESS") {
      return true;
    } else {
      return false;
    }
  }

  Future<bool> verifyPhone(String phone) async {
    final _url = Uri.http(
      _baseUrl,
      _verifyPhonePath,
      {
        'apikey': _apiKey,
        'phone': phone,
      },
    );

    final response = await httpHandler.getData(_url);

    if (response['responseMessage'] == "SUCCESS") {
      return true;
    } else {
      return false;
    }
  }

  Future<bool> shareAd(
      String adId, String type, String phone, String email) async {
    final _url = Uri.http(
      _baseUrl,
      _shareAdPath,
      {
        'apikey': _apiKey,
        'adid': adId,
        'type': type,
        'phone': phone,
        'email': email,
      },
    );

    final response = await httpHandler.getData(_url);

    if (response['responseMessage'] == "SUCCESS") {
      return true;
    } else {
      return false;
    }
  }

  Future<bool> arrangeCallback(String adId, String phone) async {
    final _url = Uri.http(
      _baseUrl,
      _arrangeCallbackPath,
      {
        'apikey': _apiKey,
        'adid': adId,
        'phone': phone,
      },
    );

    final response = await httpHandler.getData(_url);

    if (response['responseMessage'] == "SUCCESS") {
      return true;
    } else {
      return false;
    }
  }

  Future<bool> deleteFavourite(String favouriteAdsId) async {
    final _url = Uri.http(
      _baseUrl,
      _deleteFavouritePath,
      {
        'apikey': _apiKey,
        'favouriteadsid': favouriteAdsId,
      },
    );

    final response = await httpHandler.getData(_url);

    if (response['responseMessage'] == "SUCCESS") {
      return true;
    } else {
      return false;
    }
  }

  Future<bool> setFavourite(String userId, String adId) async {
    final _url = Uri.http(
      _baseUrl,
      _setFavouritesPath,
      {
        'apikey': _apiKey,
        'userid': userId,
        'adid': adId,
      },
    );

    final response = await httpHandler.getData(_url);

    if (response['responseMessage'] == "SUCCESS") {
      return true;
    } else {
      return false;
    }
  }

  Future<List<FavAd>> getFavouritesList(String userId) async {
    final _url = Uri.http(
      _baseUrl,
      _getFavouritesPath,
      {
        'apikey': _apiKey,
        'userid': userId,
      },
    );

    final response = await httpHandler.getData(_url);

    if (response['responseMessage'] == "SUCCESS") {
      List<FavAd> favAds =
          (response['response'] as List).map((e) => FavAd.fromJson(e)).toList();

      return favAds;
    } else {
      return [];
    }
  }

  Future<List<OrsAds>> getSearchResultData(
    String maincategory,
    String category,
    String country,
    String state,
    String city,
    String location,
    String latitude,
    String longitude,
    String dealer,
    String language,
    String worktype,
    String limit,
  ) async {
    final _url = Uri.http(
      _baseUrl,
      _getSearchResultPath,
      {
        'apikey': _apiKey,
        'maincategory': maincategory,
        'category': category,
        'country': country,
        'state': state,
        'city': city,
        'location': location,
        'latitude': latitude,
        'longitude': longitude,
        'dealer': dealer,
        'language': language,
        'worktype': worktype,
        'limit': limit,
      },
    );

    final response = await httpHandler.getData(_url);

    if (response['responseMessage'] == "SUCCESS") {
      List<OrsAds> listOfAds = (response['response'] as List)
          .map((e) => OrsAds.fromJson(e))
          .toList();

      return listOfAds;
    } else {
      return [];
    }
  }

  Future<List<OrsCategory>> getCategoryList(String mainCategory) async {
    final _url = Uri.http(
      _baseUrl,
      _getCategoryPath,
      {
        'apikey': _apiKey,
        'maincategory': mainCategory,
      },
    );

    final response = await httpHandler.getData(_url);

    if (response['responseMessage'] == "SUCCESS") {
      List<OrsCategory> list = (response['response'] as List)
          .map((e) => OrsCategory.fromJson(e))
          .toList();

      return list;
    } else {
      return [];
    }
  }

  Future<List<MainCategory>> getMainCategoryList() async {
    final _url = Uri.http(
      _baseUrl,
      _getMainCategoryPath,
      {
        'apikey': _apiKey,
      },
    );

    final response = await httpHandler.getData(_url);

    if (response['responseMessage'] == "SUCCESS") {
      List<MainCategory> list = (response['response'] as List)
          .map((e) => MainCategory.fromJson(e))
          .toList();

      return list;
    } else {
      return [];
    }
  }

  Future<Map> getOtpByPhone(String phone) async {
    final _url = Uri.http(
      _baseUrl,
      _otpPath,
      {
        'phone': "1$phone",
        'apikey': _apiKey,
      },
    );

    final response = await httpHandler.getData(_url);

    log(response.toString());

    if (response['responseMessage'] == "SUCCESS") {
      return {
        'success': true,
        'otp': response['response']['otp'],
      };
    } else {
      return {
        'success': false,
        'otp': null,
      };
    }
  }

  Future<bool> setPassword(String phone, String password) async {
    final _url = Uri.http(
      _baseUrl,
      _changePasswordPath,
      {
        'apikey': _apiKey,
        'phone': phone,
        'newpassword': password,
      },
    );

    final response = await httpHandler.getData(_url);

    if (response['responseMessage'] == "SUCCESS") {
      return true;
    } else {
      return false;
    }
  }
}
