import 'dart:convert';
import 'package:flutter/material.dart';

import 'package:http/http.dart' as http;

class HandleHTTP {
  Map onError(String error) {
    return {
      'responseMessage': "ERROR",
      'response': error,
    };
  }

  Future<dynamic> getData(Uri url) async {
    try {
      http.Response response = await http.get(
        url,
        headers: {"Accept": "application/json; charset=UTF-8"},
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        debugPrint("error ${response.statusCode}");
        return onError("error ${response.statusCode}");
      }
    } catch (e) {
      debugPrint(e.toString());
      return onError(e.toString());
    }
  }

  Future multipartRequest(http.MultipartRequest request) async {
    http.Response _response;
    dynamic _finalResponse;

    try {
      _response = await http.Response.fromStream(await request.send());

      if (_response.statusCode == 201 || _response.statusCode == 200) {
        _finalResponse = jsonDecode(_response.body);
      } else {
        debugPrint("error ${_response.statusCode}");
        _finalResponse = onError("error ${_response.statusCode}");
      }
    } catch (e) {
      debugPrint(e.toString());
      _finalResponse = onError(e.toString());
    }

    return _finalResponse;
  }
}
