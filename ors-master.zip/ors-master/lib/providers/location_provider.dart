import 'package:flutter/material.dart';
import 'package:ors/api/http_handler.dart';
import 'package:ors/models/data_model.dart';

class LocationProvider extends ChangeNotifier {
  final String _baseUrl = 'nationalusa.net';
  final String _getLocationsPath = 'api/getlocationlistbyname';
  final String _locationAPIkey = 'a1nm2o55l5';

  HandleHTTP httpHandler = HandleHTTP();

  Future<List<Places>> getLocations(String input) async {
    final _url = Uri.https(
      _baseUrl,
      _getLocationsPath,
      {
        'apikey': _locationAPIkey,
        'name': input,
      },
    );

    final response = await httpHandler.getData(_url);

    if (response['responseMessage'] == "SUCCESS") {
      var listOfPlaces = (response['response'] as List)
          .map((e) => Places.fromJson(e))
          .toList();

      notifyListeners();

      return listOfPlaces;
    } else {
      notifyListeners();

      return [];
    }
  }
}

class LocationProviderLegacy extends ChangeNotifier {
  final String _baseUrl = 'maps.googleapis.com';
  final String _locationAPIkey = 'AIzaSyBoi_cpgvQj217kDrakkTvyQ0KThIsPWG8';

  final String _autoCompletePath = 'maps/api/place/autocomplete/json';
  final String _placeDetailsPath = 'maps/api/place/details/json';

  HandleHTTP httpHandler = HandleHTTP();

  Future<List<PlacesLegacy>> getLocations(String input) async {
    final _url = Uri.https(
      _baseUrl,
      _autoCompletePath,
      {
        'input': input,
        'types': "geocode",
        'key': _locationAPIkey,
      },
    );

    final response = await httpHandler.getData(_url);

    if (response['status'] == "OK") {
      List<PlacesLegacy> listOfPlaces = (response['predictions'] as List)
          .map((e) => PlacesLegacy.fromJson(e, null, null))
          .toList();

      notifyListeners();

      return listOfPlaces;
    } else {
      notifyListeners();

      return [];
    }
  }

  Future<Map<String, dynamic>> getLocationDetails(Places selectedPlace) async {
    final _url = Uri.https(
      _baseUrl,
      _placeDetailsPath,
      {
        'place_id': selectedPlace.id,
        'key': _locationAPIkey,
      },
    );

    final response = await httpHandler.getData(_url);

    if (response['status'] == "OK") {
      PlacesLegacy finalPlace = PlacesLegacy.fromJson(
        {
          'place_id': selectedPlace.id,
          'description': selectedPlace.name,
        },
        response['result']['geometry']['location']['lat'].toString(),
        response['result']['geometry']['location']['lng'].toString(),
      );

      notifyListeners();

      return {
        'success': true,
        'place': finalPlace,
      };
    } else {
      notifyListeners();

      return {
        'success': false,
        'place': null,
      };
    }
  }
}
