import 'dart:io';

import 'package:flutter/material.dart';
import 'package:ors/api/http_handler.dart';
import 'package:ors/models/data_model.dart';
import 'package:ors/models/user_model.dart';
import 'package:ors/services/user_prefs.dart';
import 'package:http/http.dart' as http;

class AuthProvider extends ChangeNotifier {
  final String _baseUrl = 'www.onlineroadservices.com';
  final String _apiKey = 'ak8nui95ml00a12rw5in55gs';

  final String _loginPath = 'api/login';
  final String _signupPath = 'api/signup';
  final String _updatePath = 'api/profilechange';
  final String _updateProfilePic = 'api/profilepicupdate';

  HandleHTTP httpHandler = HandleHTTP();
  UserPreferences userPreferences = UserPreferences();

  Future<Map> login(String phone, String password) async {
    final url = Uri.http(
      _baseUrl,
      _loginPath,
      {
        'username': phone,
        'password': password,
        'apikey': _apiKey,
      },
    );

    final response = await httpHandler.getData(url);

    if (response['responseMessage'] == "SUCCESS") {
      OrsUser authUser = OrsUser.fromJson(response['response']);
      userPreferences.saveUser(authUser);

      notifyListeners();

      return {
        'status': true,
        'user': authUser,
      };
    } else {
      notifyListeners();

      return {
        'status': false,
        'user': null,
      };
    }
  }

  Future<Map> signup(
    String name,
    String password,
    String phone,
    String usertype,
  ) async {
    final _url = Uri.http(
      _baseUrl,
      _signupPath,
      {
        'apikey': _apiKey,
        'name': name,
        'password': password,
        'phoneverify': '1',
        'phone': phone,
        'usertype': usertype,
      },
    );

    final response = await httpHandler.getData(_url);

    if (response['responseMessage'] == "SUCCESS") {
      OrsUser authUser = OrsUser.fromJson(response['response']);
      userPreferences.saveUser(authUser);

      notifyListeners();

      return {
        'status': true,
        'user': authUser,
      };
    } else {
      notifyListeners();

      return {
        'status': false,
        'user': response['response'].toString(), // null,
      };
    }
  }

  Future updateProfile(
    String userId,
    String name,
    String email,
    String phone,
    Places location,
  ) async {
    final _url = Uri.http(
      _baseUrl,
      _updatePath,
      {
        'apikey': _apiKey,
        'userid': userId,
        'name': name,
        'email': email,
        'phone': phone,
        'country': location.country,
        'state': location.state,
        'city': location.city,
        'address': location.name,
        'latitude': location.lat,
        'longitude': location.lng,
      },
    );

    final response = await httpHandler.getData(_url);

    if (response['responseMessage'] == "SUCCESS") {
      OrsUser authUser = OrsUser.fromJson(response['response']);
      userPreferences.saveUser(authUser);

      notifyListeners();

      return {
        'status': true,
        'user': authUser,
      };
    } else {
      notifyListeners();

      return {
        'status': false,
        'user': null,
      };
    }
  }

  Future<bool> profilePic(String userId, String imgPath) async {
    final _url = Uri.http(
      _baseUrl,
      _updateProfilePic,
      {
        'apikey': _apiKey,
        'userid': userId,
      },
    );

    final _request = http.MultipartRequest('POST', _url)
      ..headers.addAll({
        'Content-Type': 'multipart/form-data',
        'Accept': '*/*',
        'Accept-Encoding': 'gzip, deflate, br',
        'Connection': 'keep-alive',
      })
      ..files.add(
        http.MultipartFile(
          'file',
          File(imgPath).readAsBytes().asStream(),
          (await File(imgPath).length()),
          filename: imgPath.split("/").last,
        ),
      );

    final response = await httpHandler.multipartRequest(_request);

    if (response['responseMessage'] == "SUCCESS") {
      userPreferences.updateProfilePicPath(response['response']['img']);

      return true;
    } else {
      return false;
    }
  }
}
