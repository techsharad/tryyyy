import 'package:flutter/material.dart';
import 'package:ors/models/user_model.dart';

class OrsUserProvider extends ChangeNotifier {
  OrsUser? _orsUser;

  OrsUser? get user => _orsUser;

  set setUserAtRunTime(OrsUser? user) {
    _orsUser = user;
  }

  void setUser(OrsUser? user) {
    _orsUser = user;
    notifyListeners();
  }
}
