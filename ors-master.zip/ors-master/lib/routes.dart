import 'package:flutter/material.dart';
import 'package:ors/colour_schemes.dart';
import 'package:ors/screens/home.dart';

class Routes {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case '/':
        return MaterialPageRoute(builder: (context) => const LandingPage());

      default:
        return MaterialPageRoute(
          builder: (context) => Scaffold(
            backgroundColor: kBGPaint,
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  Text(
                    "Entered Wrong Route",
                    style: TextStyle(color: kPrimary),
                    textScaleFactor: 1.2,
                  ),
                  Text(
                    "Please go back",
                    style: TextStyle(color: kSecondary),
                  ),
                ],
              ),
            ),
          ),
        );
    }
  }
}
