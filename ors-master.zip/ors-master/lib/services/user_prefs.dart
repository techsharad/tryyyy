import 'package:ors/models/user_model.dart';
import 'package:shared_preferences/shared_preferences.dart';

class UserPreferences {
  Future updateProfilePicPath(String newPath) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();

    prefs.setString('img', newPath);
  }

  Future saveUser(OrsUser user) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();

    prefs.setInt('id', user.userId);
    prefs.setString('name', user.name);
    prefs.setString('phone', user.phone);
    prefs.setString('usertype', user.userType);
    prefs.setString('email', user.email.toString());
    prefs.setString('company', user.company.toString());
    prefs.setString('img', user.imgPath.toString());
    prefs.setString('address', user.address.toString());
  }

  Future<dynamic> getUser() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();

    int? userId = prefs.getInt('id');
    String? name = prefs.getString('name');
    String? phone = prefs.getString('phone');
    String? userType = prefs.getString('usertype');
    String? email = prefs.getString('email');
    String? company = prefs.getString('company');
    String? img = prefs.getString('img');
    String? address = prefs.getString('address');

    if (userId == null) {
      return null;
    } else {
      return OrsUser(
        userId: userId,
        name: name as String,
        phone: phone as String,
        userType: userType as String,
        email: email,
        company: company,
        imgPath: img,
        address: address,
      );
    }
  }

  Future removeUser() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();

    prefs.remove('id');
    prefs.remove('name');
    prefs.remove('phone');
    prefs.remove('usertype');
    prefs.remove('email');
    prefs.remove('company');
    prefs.remove('img');
    prefs.remove('address');
  }
}
