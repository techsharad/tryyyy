import 'package:flutter/material.dart';

const Color kPrimary = Color(0xFF5F9595);
const Color kSecondary = Color(0xFFFFA22B);
const Color kBGPaint = Color(0xFFF1F1F1);
const Color kLightGrey = Color(0xFFD2D4D8);
