class OrsUser {
  int userId;
  String name, phone, userType;
  String? email, company, imgPath, address;

  OrsUser({
    required this.userId,
    required this.name,
    required this.phone,
    required this.userType,
    this.email,
    this.company,
    this.imgPath,
    this.address,
  });

  factory OrsUser.fromJson(Map json) {
    return OrsUser(
      userId: json['userid'],
      name: json['username'],
      phone: json['phone'],
      userType: json['usertype'],
      email: json['email'].toString(),
      company: json['company'].toString(),
      imgPath: json['img'].toString(),
      address: json['address'].toString(),
    );
  }
}
