import 'package:ors/models/user_model.dart';

class Places {
  int id;
  String name, lat, lng, country, state, city;

  Places({
    required this.id,
    required this.name,
    required this.lat,
    required this.lng,
    required this.country,
    required this.state,
    required this.city,
  });

  factory Places.fromJson(Map json) {
    return Places(
      id: json['locationid'],
      name: json['location'],
      lat: json['latitude'],
      lng: json['longitude'],
      country: json['country']['name'],
      state: json['state']['name'],
      city: json['city']['name'],
    );
  }
}

class MainCategory {
  int id;
  String name;

  MainCategory({
    required this.id,
    required this.name,
  });

  factory MainCategory.fromJson(Map json) {
    return MainCategory(
      id: json['maincategoryid'],
      name: json['name'],
    );
  }
}

class OrsCategory {
  int id;
  String name;

  OrsCategory({
    required this.id,
    required this.name,
  });

  factory OrsCategory.fromJson(Map json) {
    return OrsCategory(
      id: json['categoryid'],
      name: json['name'],
    );
  }
}

class OrsPlan {
  int id;
  String name, price, imgUrl, duration, templateCode, thumbnail;

  OrsPlan({
    required this.id,
    required this.name,
    required this.price,
    required this.imgUrl,
    required this.duration,
    required this.templateCode,
    required this.thumbnail,
  });

  factory OrsPlan.fromJson(Map json) {
    return OrsPlan(
      id: json['planid'],
      name: json['name'],
      price: json['price'].toString(),
      imgUrl: json['imgurl'].toString(),
      duration: json['duration'].toString(),
      templateCode: json['templatecode'].toString(),
      thumbnail: json['thumbnail'].toString(),
    );
  }
}

class OrsSubscription {}

class OrsAds {
  int id;
  OrsPlan plan;
  OrsUser? user;
  MainCategory mainCategory;
  OrsCategory category;
  OrsSubscription? subscription;
  String company,
      service1,
      service2,
      service3,
      service4,
      phone,
      location,
      timing,
      workType,
      lat,
      lng,
      img;
  String? city, state, country, website, email, customerType;

  OrsAds({
    required this.id,
    required this.plan,
    required this.mainCategory,
    required this.category,
    required this.company,
    required this.service1,
    required this.service2,
    required this.service3,
    required this.service4,
    required this.phone,
    required this.location,
    required this.timing,
    required this.workType,
    required this.lat,
    required this.lng,
    required this.img,
  });

  factory OrsAds.fromJson(Map json) {
    return OrsAds(
      id: json['adsid'],
      plan: OrsPlan.fromJson(json['plan']),
      mainCategory: MainCategory.fromJson(json['maincategory']),
      category: OrsCategory.fromJson(json['category']),
      company: json['company'].toString(),
      service1: json['service1'].toString(),
      service2: json['service2'].toString(),
      service3: json['service3'].toString(),
      service4: json['service4'].toString(),
      phone: json['phone'].toString(),
      location: json['location'].toString(),
      timing: json['hours24'].toString(),
      workType: json['worktype'].toString(),
      lat: json['latitude'].toString(),
      lng: json['longitude'].toString(),
      img: json['imgurl'].toString(),
    );
  }
}

class FavAd {
  int favAdId;
  OrsAds ad;

  FavAd({
    required this.favAdId,
    required this.ad,
  });

  factory FavAd.fromJson(Map json) {
    return FavAd(
      favAdId: json['favouriteadsid'],
      ad: OrsAds.fromJson(json['adsid']),
    );
  }
}

class PlacesLegacy {
  String id, name;
  String? lat, lng, country, state, city;

  PlacesLegacy({
    required this.id,
    required this.name,
    this.lat,
    this.lng,
    this.country,
    this.state,
    this.city,
  });

  factory PlacesLegacy.fromJson(Map json, String? lat, String? lng) {
    Map getCityStateCountry(String input) {
      List<String> data = input.split(", ");

      if (data.length >= 3) {
        List strippedData = [];

        for (var i = data.length - 1; i > data.length - 4; i--) {
          strippedData.add(data[i]);
        }

        return {
          'city': strippedData[2],
          'state': strippedData[1],
          'country': strippedData[0],
        };
      } else {
        return {
          'city': null,
          'state': null,
          'country': null,
        };
      }
    }

    return PlacesLegacy(
      id: json['place_id'],
      name: json['description'],
      lat: lat,
      lng: lng,
      country: getCityStateCountry(json['description'])['country'],
      state: getCityStateCountry(json['description'])['state'],
      city: getCityStateCountry(json['description'])['city'],
    );
  }
}
