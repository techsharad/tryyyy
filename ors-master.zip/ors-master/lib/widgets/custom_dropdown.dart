import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:ors/colour_schemes.dart';
import 'package:ors/models/data_model.dart';
import 'package:ors/providers/location_provider.dart';
import 'package:provider/provider.dart';

class MyDropdown extends StatefulWidget {
  final String title;
  final Color titleColor;
  final Icon icon;
  final Object? value;
  final List<Map>? items;
  final ValueChanged onChanged;
  final bool isAddressField;
  final Future? customAction;

  const MyDropdown({
    Key? key,
    required this.title,
    required this.titleColor,
    required this.icon,
    required this.value,
    this.items,
    required this.onChanged,
    required this.isAddressField,
    this.customAction,
  }) : super(key: key);

  @override
  _MyDropdownState createState() => _MyDropdownState();
}

class _MyDropdownState extends State<MyDropdown> {
  final GlobalKey dropdownKey = GlobalKey();

  TextEditingController addressController = TextEditingController();

  OverlayEntry? dropdownEntry;

  Size? size;
  Offset? offset;

  bool isDrawerOpened = false;
  bool isExecutingCustomAction = false;
  bool receivingPlaceDetails = false;

  String? inputAddress;
  List<Places> localItems = [];

  Object? selectedValue;

  @override
  void initState() {
    super.initState();

    getSizeAndOffset();
  }

  void removeCard() {
    dropdownEntry!.remove();
  }

  void getSizeAndOffset() {
    WidgetsBinding.instance!.addPostFrameCallback((timeStamp) {
      final RenderBox box =
          dropdownKey.currentContext!.findRenderObject() as RenderBox;

      setState(() {
        size = box.size;
        offset = box.localToGlobal(Offset.zero);
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    LocationProvider locationProvider =
        Provider.of<LocationProvider>(context, listen: false);

    void pushCard() {
      dropdownEntry = OverlayEntry(
        builder: (context) {
          return Stack(
            fit: StackFit.loose,
            children: [
              GestureDetector(
                onTap: () {
                  removeCard();
                  setState(() {
                    isDrawerOpened = false;
                  });
                },
                child: Container(
                  height: double.maxFinite,
                  width: double.maxFinite,
                  color: Colors.transparent,
                ),
              ),
              Positioned(
                top: (widget.isAddressField)
                    ? offset!.dy + size!.height + 8.0
                    : offset!.dy + 8.0,
                left: offset!.dx + 8.0,
                child: (widget.isAddressField)
                    ? Consumer<LocationProvider>(
                        builder: (context, d0, w0) => addressDropdownCard(),
                      )
                    : dropdownCard(),
              ),
            ],
          );
        },
      );

      Overlay.of(context)!.insert(dropdownEntry!);
    }

    return Padding(
      key: dropdownKey,
      padding: const EdgeInsets.all(8.0),
      child: SizedBox(
        height: double.maxFinite,
        width: double.maxFinite,
        child: (widget.isAddressField)
            ? Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Flexible(
                    flex: 4,
                    child: Stack(
                      alignment: Alignment.centerLeft,
                      children: [
                        (inputAddress == null ||
                                inputAddress == "" ||
                                selectedValue != null)
                            ? Text(
                                (selectedValue == null)
                                    ? widget.title
                                    : selectedValue.toString(),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  color: widget.titleColor,
                                  fontWeight: FontWeight.w500,
                                ),
                              )
                            : Container(),
                        TextFormField(
                          controller: addressController,
                          maxLines: 1,
                          enableInteractiveSelection: false,
                          enableSuggestions: false,
                          keyboardType: TextInputType.streetAddress,
                          style: TextStyle(
                            color: widget.titleColor,
                            fontWeight: FontWeight.w500,
                          ),
                          cursorColor: kPrimary,
                          cursorRadius: const Radius.circular(30.0),
                          decoration:
                              const InputDecoration(border: InputBorder.none),
                          onChanged: (input) async {
                            widget.onChanged.call(null);

                            if (!isDrawerOpened) {
                              pushCard();
                            }

                            setState(() {
                              selectedValue = null;
                              isDrawerOpened = true;
                              inputAddress = input;
                            });

                            if (input == "") {
                              removeCard();
                              setState(() {
                                isDrawerOpened = false;
                              });
                            }

                            localItems =
                                await locationProvider.getLocations(input);
                          },
                        ),
                      ],
                    ),
                  ),
                  Flexible(
                    child: (receivingPlaceDetails)
                        ? const AspectRatio(
                            aspectRatio: 1,
                            child: Padding(
                              padding: EdgeInsets.all(5.0),
                              child:
                                  CircularProgressIndicator(color: kSecondary),
                            ),
                          )
                        : widget.icon,
                  ),
                ],
              )
            : GestureDetector(
                onTap: () {
                  if (isDrawerOpened) {
                    dropdownEntry!.remove();
                  } else {
                    pushCard();
                  }

                  setState(() {
                    isDrawerOpened = !isDrawerOpened;
                  });
                },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Flexible(
                      flex: 4,
                      child: Text(
                        (selectedValue == null)
                            ? widget.title
                            : selectedValue.toString(),
                        style: TextStyle(
                          color: widget.titleColor,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                    Flexible(
                      child: RotatedBox(
                        quarterTurns: (isDrawerOpened) ? 2 : 0,
                        child: widget.icon,
                      ),
                    ),
                  ],
                ),
              ),
      ),
    );
  }

  Widget dropdownCard() {
    return Card(
      elevation: 15.0,
      color: Colors.grey[100],
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12.0),
        side: BorderSide(
          color: kPrimary.withOpacity(0.5),
          width: 1.5,
        ),
      ),
      child: Container(
        padding: const EdgeInsets.all(5.0),
        constraints: BoxConstraints(
          maxWidth: size!.width - 45.0,
          minWidth: size!.width - 45.0,
          maxHeight: MediaQuery.of(context).size.height * 0.4,
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: widget.items!
                .map(
                  (e) => Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      ListTile(
                        onTap: () {
                          widget.onChanged.call(
                              [e['value'].toString(), e['child'].toString()]);

                          removeCard();

                          setState(() {
                            selectedValue = e['child'];
                            isDrawerOpened = !isDrawerOpened;
                          });
                        },
                        title: Text(
                          e['child'].toString(),
                          textScaleFactor: 1.15,
                          style: const TextStyle(
                            color: kPrimary,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        dense: true,
                        minVerticalPadding: 0.0,
                      ),
                      Divider(
                        color: kPrimary.withOpacity(0.2),
                        thickness: 1.2,
                        height: 0.0,
                        indent: 10.0,
                        endIndent: 10.0,
                      ),
                    ],
                  ),
                )
                .toList(),
          ),
        ),
      ),
    );
  }

  Widget addressDropdownCard() {
    return Card(
      elevation: 15.0,
      color: Colors.grey[100],
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12.0),
        side: BorderSide(
          color: kPrimary.withOpacity(0.5),
          width: 1.5,
        ),
      ),
      child: Container(
        padding: const EdgeInsets.all(5.0),
        constraints: BoxConstraints(
          maxWidth: size!.width - 45.0,
          minWidth: size!.width - 45.0,
          maxHeight: MediaQuery.of(context).size.height * 0.4,
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: const EdgeInsets.only(
                  left: 16.0,
                  right: 64.0,
                  top: 5.0,
                  bottom: 3.0,
                ),
                child:
                    Image.asset('assets/icon/powered_by_google_on_white.png'),
              ),
              Column(
                mainAxisSize: MainAxisSize.min,
                children: localItems
                    .map(
                      (e) => Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          ListTile(
                            onTap: () async {
                              setState(() {
                                receivingPlaceDetails = true;
                              });

                              /* Map resp =
                              await LocationProvider().getLocationDetails(e); */

                              setState(() {
                                receivingPlaceDetails = false;
                              });

                              widget.onChanged.call(e);

                              removeCard();

                              setState(() {
                                selectedValue = e.name;
                                isDrawerOpened = false;
                                //addressController.text = "";
                                addressController.clear();
                              });

                              FocusScopeNode currentFocus =
                                  FocusScope.of(context);

                              if (!currentFocus.hasPrimaryFocus) {
                                currentFocus.unfocus();
                              }

                              /* if (resp['success']) {
                            widget.onChanged.call(resp['place']);

                            removeCard();

                            setState(() {
                              selectedValue = resp['place'].name;
                              isDrawerOpened = false;
                              //addressController.text = "";
                              addressController.clear();
                            });

                            FocusScopeNode currentFocus =
                                FocusScope.of(context);

                            if (!currentFocus.hasPrimaryFocus) {
                              currentFocus.unfocus();
                            }
                          } else {
                            Fluttertoast.showToast(
                              msg: "Couldn't fetch location details",
                              gravity: ToastGravity.BOTTOM,
                              backgroundColor: kPrimary,
                              textColor: Colors.white,
                            );
                          } */
                            },
                            title: Text(
                              e.name,
                              textScaleFactor: 1.15,
                              style: const TextStyle(
                                color: kPrimary,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            dense: true,
                            minVerticalPadding: 0.0,
                          ),
                          Divider(
                            color: kPrimary.withOpacity(0.2),
                            thickness: 1.2,
                            height: 0.0,
                            indent: 10.0,
                            endIndent: 10.0,
                          ),
                        ],
                      ),
                    )
                    .toList(),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
