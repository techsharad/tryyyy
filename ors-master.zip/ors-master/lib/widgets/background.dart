import 'package:flutter/material.dart';
import 'package:ors/colour_schemes.dart';

class BackgroundPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final Paint _paint = Paint()
      ..color = kBGPaint
      ..style = PaintingStyle.fill;

    final Path _path = Path()
      ..moveTo(size.width * 3 / 4, 0)
      ..quadraticBezierTo(
        size.width / 2,
        size.height * 0.25,
        size.width,
        size.height * 0.45,
      )
      ..lineTo(size.width, 0)
      ..moveTo(0, size.height)
      ..lineTo(size.width * 1 / 3, size.height)
      ..quadraticBezierTo(
        size.width * 0.3,
        size.height * 0.8,
        0,
        size.height * 0.75,
      );

    canvas.drawPath(_path, _paint);
  }

  @override
  bool shouldRepaint(BackgroundPainter oldDelegate) => false;

  @override
  bool shouldRebuildSemantics(BackgroundPainter oldDelegate) => false;
}
