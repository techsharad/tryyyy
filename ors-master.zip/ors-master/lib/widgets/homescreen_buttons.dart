import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:ors/colour_schemes.dart';

class HomeButtons extends StatelessWidget {
  const HomeButtons({Key? key}) : super(key: key);

  static List<Map> items = [
    {
      'title': "Truck Repair",
      'image': "assets/images/icon1 1.png",
    },
    {
      'title': "Trailer Repair",
      'image': "assets/images/icon3 1.png",
    },
    {
      'title': "Tire Repair",
      'image': "assets/images/icon7 1.png",
    },
    {
      'title': "Auto Parts",
      'image': "assets/images/icon5 1.png",
    },
    {
      'title': "Driving School",
      'image': "assets/images/icon6 1.png",
    },
    {
      'title': "Towing Service",
      'image': "assets/images/icon2 1.png",
    },
  ];

  Card myButtons(int i) => Card(
        color: Colors.grey[100],
        elevation: 0,
        shape: RoundedRectangleBorder(
          side: const BorderSide(color: kSecondary, width: 1.5),
          borderRadius: BorderRadius.circular(10.0),
        ),
        child: Padding(
          padding: const EdgeInsets.only(
            left: 3.0,
            right: 3.0,
            top: 4.0,
            bottom: 12.0,
          ),
          child: Column(
            children: [
              Expanded(
                child: Center(
                  child: Text(
                    items[i]['title'],
                    textAlign: TextAlign.center,
                    textScaleFactor: 0.85,
                    style: const TextStyle(
                      color: kPrimary,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              Expanded(
                child: Center(
                  child: Image.asset(items[i]['image']),
                ),
              ),
            ],
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    return SizedBox.expand(
      child: Padding(
        padding: const EdgeInsets.only(
            left: 15.0, right: 15.0, bottom: 45.0, top: 15.0),
        child: Column(
          children: [
            Expanded(
              child: Row(
                children: [
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 3, vertical: 5),
                      child: myButtons(0),
                    ),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 3, vertical: 5),
                      child: myButtons(1),
                    ),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 3, vertical: 5),
                      child: myButtons(2),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Row(
                children: [
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 3, vertical: 5),
                      child: myButtons(3),
                    ),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 3, vertical: 5),
                      child: myButtons(4),
                    ),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 3, vertical: 5),
                      child: myButtons(5),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
