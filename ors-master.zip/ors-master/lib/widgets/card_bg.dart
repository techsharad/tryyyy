import 'package:flutter/material.dart';
import 'package:ors/colour_schemes.dart';

class CardPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    Paint paint = Paint()
      ..color = kSecondary.withOpacity(0.2)
      ..style = PaintingStyle.fill;

    //Path path = Path()..moveTo(size.width, 0);

    //canvas.drawPath(path, paint);
    canvas.drawCircle(Offset(size.width, 0), size.width * 0.2, paint);
  }

  @override
  bool shouldRepaint(CardPainter oldDelegate) => false;

  @override
  bool shouldRebuildSemantics(CardPainter oldDelegate) => false;
}
