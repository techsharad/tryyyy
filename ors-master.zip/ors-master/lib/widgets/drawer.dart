import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:ors/colour_schemes.dart';
import 'package:ors/main.dart';
import 'package:ors/providers/user_provider.dart';
import 'package:ors/screens/home.dart';
import 'package:ors/screens/search.dart';
import 'package:ors/services/user_prefs.dart';
import 'package:persistent_bottom_nav_bar/persistent-tab-view.dart';
import 'package:provider/provider.dart';

class GlobalDrawer extends StatefulWidget {
  const GlobalDrawer({Key? key}) : super(key: key);

  @override
  _GlobalDrawerState createState() => _GlobalDrawerState();
}

class _GlobalDrawerState extends State<GlobalDrawer> {
  UserPreferences prefs = UserPreferences();

  @override
  Widget build(BuildContext context) {
    return Consumer(
      builder: (context, data, w) {
        return Drawer(
          child: SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(10.0),
              child: Column(
                children: [
                  ListTile(
                    onTap: () => Navigator.of(context).pop(),
                    leading: const Icon(
                      Icons.arrow_back_rounded,
                      color: kSecondary,
                    ),
                    title: const Text(
                      "Back",
                      textScaleFactor: 1.1,
                      style: TextStyle(
                        color: kPrimary,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    enableFeedback: true,
                    horizontalTitleGap: 8.0,
                  ),
                  const Divider(
                    thickness: 1.5,
                    indent: 20.0,
                    endIndent: 20.0,
                  ),
                  ListTile(
                    onTap: () {
                      Navigator.of(context).pushAndRemoveUntil(
                        CupertinoPageRoute(
                          builder: (BuildContext context) {
                            return const LandingPage();
                          },
                        ),
                        (_) => false,
                      );
                    },
                    leading: const Icon(
                      Icons.dashboard_rounded,
                      color: kSecondary,
                    ),
                    title: const Text(
                      "Dashboard",
                      textScaleFactor: 1.1,
                      style: TextStyle(
                        color: kPrimary,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    enableFeedback: true,
                    horizontalTitleGap: 8.0,
                  ),
                  const Divider(
                    thickness: 1.5,
                    indent: 20.0,
                    endIndent: 20.0,
                  ),
                  ListTile(
                    onTap: () async {
                      prefs.removeUser();

                      Provider.of<OrsUserProvider>(context, listen: false)
                          .setUser(null);

                      Fluttertoast.showToast(
                        msg: "Logged-out successfully",
                        gravity: ToastGravity.BOTTOM,
                        backgroundColor: kPrimary,
                        textColor: Colors.white,
                      );

                      ORS.restartApp(context);
                    },
                    leading: const Icon(
                      Icons.logout_rounded,
                      color: kSecondary,
                    ),
                    title: const Text(
                      "Logout",
                      textScaleFactor: 1.1,
                      style: TextStyle(
                        color: kPrimary,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    enableFeedback: true,
                    horizontalTitleGap: 8.0,
                  ),
                  const Divider(
                    thickness: 1.5,
                    indent: 20.0,
                    endIndent: 20.0,
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
