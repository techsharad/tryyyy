import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:map_launcher/map_launcher.dart';
import 'package:ors/api/web_api.dart';
import 'package:ors/colour_schemes.dart';
import 'package:ors/components/browser.dart';
import 'package:ors/models/data_model.dart';
import 'package:ors/models/user_model.dart';
import 'package:ors/providers/user_provider.dart';
import 'package:ors/screens/ad_details.dart';
import 'package:ors/test.dart';
import 'package:persistent_bottom_nav_bar/persistent-tab-view.dart';
import 'package:provider/provider.dart';
import 'package:shimmer/shimmer.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:share_plus/share_plus.dart';

class AdsCard extends StatefulWidget {
  final OrsAds ad;
  final bool isEditableAd, isDetails;
  final String? favID;
  final ValueChanged? onDelete;
  final List<int> favIds;

  const AdsCard({
    Key? key,
    required this.ad,
    required this.isEditableAd,
    required this.isDetails,
    this.favID,
    this.onDelete,
    required this.favIds,
  }) : super(key: key);

  @override
  _AdsCardState createState() => _AdsCardState();
}

class _AdsCardState extends State<AdsCard> {
  WebApi webApi = WebApi();
  final ChromeSafariBrowser browser = OpenWebsite();

  TextEditingController phoneForShareAd = TextEditingController();
  TextEditingController emailForShareAd = TextEditingController();

  RegExp mailRegex =
      RegExp(r"^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]"
          r"{0,253}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]"
          r"{0,253}[a-zA-Z0-9])?)*$");

  /* Widget temp = Shimmer.fromColors(
    child: Container(
      height: double.maxFinite,
      width: double.maxFinite,
      color: Colors.grey[100],
    ),
    baseColor: Colors.grey[100] as Color,
    highlightColor: Colors.grey[300] as Color,
  ); */

  @override
  void initState() {
    super.initState();

    localFavData = false;

    browser.addMenuItem(
      ChromeSafariBrowserMenuItem(
        id: 1,
        label: 'Vendor Website',
        action: (url, title) {
          debugPrint('Vendor Website clicked!');
        },
      ),
    );

    /* Future.delayed(
      const Duration(seconds: 2),
      () {
        setState(() {
          temp = Image.asset(
            'assets/images/fdbeb 1.png',
            fit: BoxFit.cover,
          );
        });
      },
    ); */
  }

  Widget serviceWidget(String inp) {
    if (inp != "null") {
      return Text(
        inp + ", ",
        textScaleFactor: 0.85,
      );
    } else {
      return Container();
    }
  }

  bool localFavData = false;

  @override
  Widget build(BuildContext context) {
    OrsUser? orsUser =
        Provider.of<OrsUserProvider>(context, listen: false).user;

    bool isInFavs() {
      if (widget.favIds.contains(widget.ad.id)) {
        return true;
      } else {
        return false;
      }
    }

    OverlayEntry overlayEntry = OverlayEntry(
      builder: (context) {
        return Container(
          height: double.maxFinite,
          width: double.maxFinite,
          color: Colors.black.withOpacity(0.2),
          child: const Center(
            child: SizedBox(
              height: 30.0,
              width: 30.0,
              child: CircularProgressIndicator(color: kPrimary),
            ),
          ),
        );
      },
    );

    void requestCallback() {
      TextEditingController callbackPhone = TextEditingController();

      showDialog(
        context: context,
        useSafeArea: true,
        builder: (context) {
          return Dialog(
            elevation: 15.0,
            backgroundColor: Colors.white,
            insetPadding: const EdgeInsets.all(24.0),
            shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20.0),
                bottomRight: Radius.circular(20.0),
              ),
            ),
            child: Padding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 30.0, vertical: 15.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    "Arrange Callback",
                    textScaleFactor: 1.15,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: kPrimary,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const Divider(
                    color: kSecondary,
                    thickness: 3.0,
                    height: 20.0,
                    indent: 80.0,
                    endIndent: 80.0,
                  ),
                  const SizedBox(height: 20.0),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      "Phone number *",
                      style: TextStyle(
                        color: Colors.grey[600],
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  const SizedBox(height: 12.0),
                  TextFormField(
                    controller: callbackPhone,
                    cursorRadius: const Radius.circular(50.0),
                    enableInteractiveSelection: false,
                    enableSuggestions: false,
                    keyboardType: TextInputType.phone,
                    maxLength: 10,
                    maxLines: 1,
                    style: const TextStyle(
                      color: kPrimary,
                      fontWeight: FontWeight.w500,
                    ),
                    decoration: InputDecoration(
                      contentPadding:
                          const EdgeInsets.symmetric(horizontal: 10.0),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.0),
                        borderSide: const BorderSide(
                          color: Colors.grey,
                          width: 1.2,
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.0),
                        borderSide: const BorderSide(
                          color: kPrimary,
                          width: 1.2,
                        ),
                      ),
                      counterText: '',
                    ),
                  ),
                  const SizedBox(height: 20.0),
                  MaterialButton(
                    onPressed: () => Navigator.of(context).pop(),
                    color: kSecondary,
                    elevation: 0.0,
                    height: 40.0,
                    minWidth: MediaQuery.of(context).size.width * 0.45,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.0)),
                    child: const Text(
                      "Cancel",
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                  const SizedBox(height: 10.0),
                  MaterialButton(
                    onPressed: () async {
                      if (callbackPhone.text.length == 10) {
                        Fluttertoast.showToast(
                          msg: "Request sent",
                          gravity: ToastGravity.BOTTOM,
                          backgroundColor: kPrimary,
                          textColor: Colors.white,
                        );

                        Navigator.of(context).pop();

                        await webApi.arrangeCallback(
                            widget.ad.id.toString(), callbackPhone.text);
                      } else {
                        Fluttertoast.showToast(
                          msg: "Please enter a valid phone number",
                          gravity: ToastGravity.BOTTOM,
                          backgroundColor: kPrimary,
                          textColor: Colors.white,
                        );
                      }
                    },
                    color: kPrimary,
                    elevation: 0.0,
                    height: 40.0,
                    minWidth: MediaQuery.of(context).size.width * 0.45,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.0)),
                    child: const Text(
                      "Submit",
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      );
    }

    return Card(
      elevation: (widget.isDetails) ? 0.0 : 3.0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
      child: GestureDetector(
        onTap: () {
          if (!widget.isDetails) {
            pushNewScreen(
              context,
              screen: AdsDetails(
                ad: widget.ad,
                favIds: widget.favIds,
                isEditableAd: widget.isEditableAd,
                favID: widget.favID,
              ),
              withNavBar: false,
              pageTransitionAnimation: PageTransitionAnimation.fade,
            );
          }
        },
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              Stack(
                children: [
                  (widget.ad.img != 'NA' &&
                          widget.ad.img != 'public/media/Custom1.png')
                      ? Image.memory(
                          base64Decode(widget.ad.img.replaceRange(0, 23, '')),
                          fit: BoxFit.contain,
                        )
                      : Image.asset(
                          'assets/images/fdbeb 1.png',
                          fit: BoxFit.contain,
                        ),
                  (widget.isEditableAd)
                      ? Align(
                          alignment: Alignment.topRight,
                          child: PopupMenuButton(
                            color: Colors.white,
                            icon: const Icon(
                              Icons.more_vert_rounded,
                              color: kSecondary,
                            ),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(50.0)),
                            itemBuilder: (context) {
                              return [
                                PopupMenuItem(
                                  child: const Center(
                                    child: Text(
                                      "Delete",
                                      style: TextStyle(color: kSecondary),
                                    ),
                                  ),
                                  height: kMinInteractiveDimension / 2,
                                  onTap: () async {
                                    if (await webApi
                                        .deleteFavourite(widget.favID!)) {
                                      widget.onDelete!.call(0);

                                      Fluttertoast.showToast(
                                        msg: "Favourite removed!",
                                        gravity: ToastGravity.BOTTOM,
                                        backgroundColor: kPrimary,
                                        textColor: Colors.white,
                                      );
                                    } else {
                                      Fluttertoast.showToast(
                                        msg: "Error occured",
                                        gravity: ToastGravity.BOTTOM,
                                        backgroundColor: kPrimary,
                                        textColor: Colors.white,
                                      );
                                    }
                                  },
                                ),
                              ];
                            },
                          ),
                        )
                      : Container(),
                ],
              ),
              AspectRatio(
                aspectRatio: 16 / 9,
                child: Column(
                  children: [
                    Expanded(
                      flex: 5,
                      child: Column(
                        children: [
                          Expanded(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Flexible(
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Flexible(
                                        child: FittedBox(
                                          child: Padding(
                                            padding: const EdgeInsets.all(2.0),
                                            child: GestureDetector(
                                              // onTap: () => Share.share(
                                              //    "Check-out ${widget.ad.company} at http://nearbyroadservice.com/"),
                                              onTap: () {
                                                showModalBottomSheet(
                                                  context: context,
                                                  isScrollControlled: true,
                                                  constraints: BoxConstraints(
                                                      maxHeight:
                                                          MediaQuery.of(context)
                                                                  .size
                                                                  .height *
                                                              0.65),
                                                  shape:
                                                      const RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.only(
                                                      topLeft:
                                                          Radius.circular(25.0),
                                                      topRight:
                                                          Radius.circular(25.0),
                                                    ),
                                                  ),
                                                  builder: (context) {
                                                    return SizedBox.expand(
                                                      child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .all(25.0),
                                                        child:
                                                            DefaultTabController(
                                                          length: 2,
                                                          child: Column(
                                                            children: [
                                                              Flexible(
                                                                child: Align(
                                                                  alignment:
                                                                      Alignment
                                                                          .topCenter,
                                                                  child:
                                                                      Container(
                                                                    height: 6.0,
                                                                    width: 60.0,
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color:
                                                                          kPrimary,
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              50.0),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              const Expanded(
                                                                flex: 2,
                                                                child: Center(
                                                                  child: Text(
                                                                    "Share this Ad via",
                                                                    textScaleFactor:
                                                                        1.2,
                                                                    style:
                                                                        TextStyle(
                                                                      color:
                                                                          kPrimary,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w600,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              const Expanded(
                                                                flex: 2,
                                                                child: TabBar(
                                                                  tabs: [
                                                                    Tab(
                                                                      text:
                                                                          "Phone",
                                                                    ),
                                                                    Tab(
                                                                      text:
                                                                          "E-mail",
                                                                    ),
                                                                  ],
                                                                  labelColor:
                                                                      kPrimary,
                                                                  labelStyle:
                                                                      TextStyle(
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w600,
                                                                    fontFamily:
                                                                        'Inter',
                                                                  ),
                                                                  indicatorColor:
                                                                      kSecondary,
                                                                  indicatorSize:
                                                                      TabBarIndicatorSize
                                                                          .label,
                                                                  indicatorWeight:
                                                                      2.0,
                                                                ),
                                                              ),
                                                              Expanded(
                                                                flex: 12,
                                                                child:
                                                                    TabBarView(
                                                                  children: [
                                                                    SingleChildScrollView(
                                                                      child:
                                                                          Column(
                                                                        children: [
                                                                          const SizedBox(
                                                                              height: 25.0),
                                                                          Align(
                                                                            alignment:
                                                                                Alignment.centerLeft,
                                                                            child:
                                                                                Text(
                                                                              "Phone Number *",
                                                                              style: TextStyle(
                                                                                color: Colors.grey[600],
                                                                                fontWeight: FontWeight.bold,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          const SizedBox(
                                                                              height: 12.0),
                                                                          TextFormField(
                                                                            controller:
                                                                                phoneForShareAd,
                                                                            cursorRadius:
                                                                                const Radius.circular(50.0),
                                                                            enableInteractiveSelection:
                                                                                false,
                                                                            enableSuggestions:
                                                                                false,
                                                                            keyboardType:
                                                                                TextInputType.phone,
                                                                            maxLength:
                                                                                10,
                                                                            maxLines:
                                                                                1,
                                                                            style:
                                                                                const TextStyle(
                                                                              color: kPrimary,
                                                                              fontWeight: FontWeight.w500,
                                                                            ),
                                                                            decoration:
                                                                                InputDecoration(
                                                                              enabledBorder: OutlineInputBorder(
                                                                                borderRadius: BorderRadius.circular(10.0),
                                                                                borderSide: const BorderSide(
                                                                                  color: Colors.grey,
                                                                                  width: 1.2,
                                                                                ),
                                                                              ),
                                                                              focusedBorder: OutlineInputBorder(
                                                                                borderRadius: BorderRadius.circular(10.0),
                                                                                borderSide: const BorderSide(
                                                                                  color: kPrimary,
                                                                                  width: 1.2,
                                                                                ),
                                                                              ),
                                                                              counterText: '',
                                                                            ),
                                                                          ),
                                                                          const SizedBox(
                                                                              height: 25.0),
                                                                          MaterialButton(
                                                                            onPressed:
                                                                                () async {
                                                                              if (phoneForShareAd.text.length == 10) {
                                                                                Overlay.of(context)!.insert(overlayEntry);

                                                                                bool resp = await webApi.shareAd(widget.ad.id.toString(), 'phoneSel', phoneForShareAd.text, "email");

                                                                                overlayEntry.remove();

                                                                                if (resp) {
                                                                                  Navigator.of(context).pop();

                                                                                  Fluttertoast.showToast(
                                                                                    msg: "Ad shared successfully",
                                                                                    gravity: ToastGravity.BOTTOM,
                                                                                    backgroundColor: kPrimary,
                                                                                    textColor: Colors.white,
                                                                                  );
                                                                                } else {
                                                                                  Fluttertoast.showToast(
                                                                                    msg: "Ad share failed",
                                                                                    gravity: ToastGravity.BOTTOM,
                                                                                    backgroundColor: kPrimary,
                                                                                    textColor: Colors.white,
                                                                                  );
                                                                                }
                                                                              } else {
                                                                                Fluttertoast.showToast(
                                                                                  msg: "Phone number not valid",
                                                                                  gravity: ToastGravity.BOTTOM,
                                                                                  backgroundColor: kPrimary,
                                                                                  textColor: Colors.white,
                                                                                );
                                                                              }
                                                                            },
                                                                            color:
                                                                                kSecondary,
                                                                            elevation:
                                                                                0.0,
                                                                            height:
                                                                                50.0,
                                                                            minWidth:
                                                                                MediaQuery.of(context).size.width * 0.55,
                                                                            shape:
                                                                                RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
                                                                            child:
                                                                                const Text(
                                                                              "Share Ad",
                                                                              style: TextStyle(color: Colors.white),
                                                                            ),
                                                                          ),
                                                                          SizedBox(
                                                                              height: MediaQuery.of(context).viewInsets.bottom),
                                                                        ],
                                                                      ),
                                                                    ),
                                                                    SingleChildScrollView(
                                                                      child:
                                                                          Column(
                                                                        children: [
                                                                          const SizedBox(
                                                                              height: 25.0),
                                                                          Align(
                                                                            alignment:
                                                                                Alignment.centerLeft,
                                                                            child:
                                                                                Text(
                                                                              "E-mail id *",
                                                                              style: TextStyle(
                                                                                color: Colors.grey[600],
                                                                                fontWeight: FontWeight.bold,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          const SizedBox(
                                                                              height: 12.0),
                                                                          TextFormField(
                                                                            controller:
                                                                                emailForShareAd,
                                                                            cursorRadius:
                                                                                const Radius.circular(50.0),
                                                                            enableInteractiveSelection:
                                                                                false,
                                                                            enableSuggestions:
                                                                                false,
                                                                            keyboardType:
                                                                                TextInputType.emailAddress,
                                                                            maxLines:
                                                                                1,
                                                                            style:
                                                                                const TextStyle(
                                                                              color: kPrimary,
                                                                              fontWeight: FontWeight.w500,
                                                                            ),
                                                                            decoration:
                                                                                InputDecoration(
                                                                              enabledBorder: OutlineInputBorder(
                                                                                borderRadius: BorderRadius.circular(10.0),
                                                                                borderSide: const BorderSide(
                                                                                  color: Colors.grey,
                                                                                  width: 1.2,
                                                                                ),
                                                                              ),
                                                                              focusedBorder: OutlineInputBorder(
                                                                                borderRadius: BorderRadius.circular(10.0),
                                                                                borderSide: const BorderSide(
                                                                                  color: kPrimary,
                                                                                  width: 1.2,
                                                                                ),
                                                                              ),
                                                                              counterText: '',
                                                                            ),
                                                                          ),
                                                                          const SizedBox(
                                                                              height: 25.0),
                                                                          MaterialButton(
                                                                            onPressed:
                                                                                () async {
                                                                              if (mailRegex.hasMatch(emailForShareAd.text) && emailForShareAd.text.isNotEmpty) {
                                                                                Overlay.of(context)!.insert(overlayEntry);

                                                                                bool resp = await webApi.shareAd(widget.ad.id.toString(), 'emailSel', "phone", emailForShareAd.text);

                                                                                overlayEntry.remove();

                                                                                if (resp) {
                                                                                  Navigator.of(context).pop();

                                                                                  Fluttertoast.showToast(
                                                                                    msg: "Ad shared successfully",
                                                                                    gravity: ToastGravity.BOTTOM,
                                                                                    backgroundColor: kPrimary,
                                                                                    textColor: Colors.white,
                                                                                  );
                                                                                } else {
                                                                                  Fluttertoast.showToast(
                                                                                    msg: "Ad share failed",
                                                                                    gravity: ToastGravity.BOTTOM,
                                                                                    backgroundColor: kPrimary,
                                                                                    textColor: Colors.white,
                                                                                  );
                                                                                }
                                                                              } else {
                                                                                Fluttertoast.showToast(
                                                                                  msg: "E-mail id not valid",
                                                                                  gravity: ToastGravity.BOTTOM,
                                                                                  backgroundColor: kPrimary,
                                                                                  textColor: Colors.white,
                                                                                );
                                                                              }
                                                                            },
                                                                            color:
                                                                                kSecondary,
                                                                            elevation:
                                                                                0.0,
                                                                            height:
                                                                                50.0,
                                                                            minWidth:
                                                                                MediaQuery.of(context).size.width * 0.55,
                                                                            shape:
                                                                                RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
                                                                            child:
                                                                                const Text(
                                                                              "Share Ad",
                                                                              style: TextStyle(color: Colors.white),
                                                                            ),
                                                                          ),
                                                                          SizedBox(
                                                                              height: MediaQuery.of(context).viewInsets.bottom),
                                                                        ],
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    );
                                                  },
                                                );
                                              },
                                              child: const Icon(
                                                Icons.share_rounded,
                                                color: kSecondary,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      const Flexible(
                                        child: SizedBox(width: 7.0),
                                      ),
                                      Flexible(
                                        child: FittedBox(
                                          child: Padding(
                                            padding: const EdgeInsets.all(2.0),
                                            child: GestureDetector(
                                              onTap: () async {
                                                final availableMaps =
                                                    await MapLauncher
                                                        .installedMaps;

                                                /*await availableMaps.first
                                                    .showMarker(
                                                  coords: Coords(
                                                    double.parse(widget.ad.lat),
                                                    double.parse(widget.ad.lng),
                                                  ),
                                                  title: widget.ad.company,
                                                  description: widget.ad.company,
                                                );*/

                                                await availableMaps.first
                                                    .showDirections(
                                                  destination: Coords(
                                                    double.parse(widget.ad.lat),
                                                    double.parse(widget.ad.lng),
                                                  ),
                                                  directionsMode:
                                                      DirectionsMode.driving,
                                                  destinationTitle:
                                                      widget.ad.company,
                                                );
                                              },
                                              child: const Icon(
                                                Icons.near_me_rounded,
                                                color: kSecondary,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      const Flexible(
                                        child: SizedBox(width: 7.0),
                                      ),
                                      (!widget.isEditableAd)
                                          ? Flexible(
                                              child: FittedBox(
                                                child: Padding(
                                                  padding:
                                                      const EdgeInsets.all(2.0),
                                                  child: (!isInFavs())
                                                      ? GestureDetector(
                                                          onTap: () async {
                                                            if (orsUser !=
                                                                null) {
                                                              bool resp =
                                                                  await webApi
                                                                      .setFavourite(
                                                                orsUser.userId
                                                                    .toString(),
                                                                widget.ad.id
                                                                    .toString(),
                                                              );

                                                              if (resp) {
                                                                setState(() {
                                                                  localFavData =
                                                                      true;
                                                                });

                                                                Fluttertoast
                                                                    .showToast(
                                                                  msg:
                                                                      "Added to favourites!",
                                                                  gravity:
                                                                      ToastGravity
                                                                          .BOTTOM,
                                                                  backgroundColor:
                                                                      kPrimary,
                                                                  textColor:
                                                                      Colors
                                                                          .white,
                                                                );
                                                              } else {
                                                                Fluttertoast
                                                                    .showToast(
                                                                  msg:
                                                                      "Error occured",
                                                                  gravity:
                                                                      ToastGravity
                                                                          .BOTTOM,
                                                                  backgroundColor:
                                                                      kPrimary,
                                                                  textColor:
                                                                      Colors
                                                                          .white,
                                                                );
                                                              }
                                                            } else {
                                                              Fluttertoast
                                                                  .showToast(
                                                                msg:
                                                                    "Please login/signup to add favourite",
                                                                gravity:
                                                                    ToastGravity
                                                                        .BOTTOM,
                                                                backgroundColor:
                                                                    kPrimary,
                                                                textColor:
                                                                    Colors
                                                                        .white,
                                                              );
                                                            }
                                                          },
                                                          child: Icon(
                                                            (!localFavData)
                                                                ? Icons
                                                                    .favorite_outline_rounded
                                                                : Icons
                                                                    .favorite_rounded,
                                                            color: kSecondary,
                                                          ),
                                                        )
                                                      : GestureDetector(
                                                          onTap: () {
                                                            Fluttertoast
                                                                .showToast(
                                                              msg:
                                                                  "Already a favourite",
                                                              gravity:
                                                                  ToastGravity
                                                                      .BOTTOM,
                                                              backgroundColor:
                                                                  kPrimary,
                                                              textColor:
                                                                  Colors.white,
                                                            );
                                                          },
                                                          child: const Icon(
                                                            Icons
                                                                .favorite_rounded,
                                                            color: kSecondary,
                                                          ),
                                                        ),
                                                ),
                                              ),
                                            )
                                          : Container(),
                                    ],
                                  ),
                                ),
                                Flexible(
                                  child: GestureDetector(
                                    onTap: () async {
                                      String urlString =
                                          'tel:+1 ${widget.ad.phone}';
                                      await canLaunch(urlString)
                                          ? await launch(urlString)
                                          : throw 'Could not launch $urlString';
                                    },
                                    child: Container(
                                      padding: const EdgeInsets.all(2.0),
                                      decoration: const BoxDecoration(
                                        color: kPrimary,
                                        borderRadius: BorderRadius.only(
                                          topLeft: Radius.circular(50.0),
                                          bottomLeft: Radius.circular(50.0),
                                        ),
                                      ),
                                      child: const FittedBox(
                                        child: Text(
                                          "    CALL NOW  ",
                                          textScaleFactor: 0.95,
                                          style: TextStyle(color: Colors.white),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Expanded(
                            child: Align(
                              alignment: Alignment.centerLeft,
                              child: Text(
                                widget.ad.company.toString(),
                                style: const TextStyle(
                                  color: kPrimary,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ),
                          Expanded(
                            flex: 2,
                            child: Row(
                              children: [
                                Expanded(
                                  child: Wrap(
                                    children: [
                                      serviceWidget(widget.ad.service1),
                                      serviceWidget(widget.ad.service2),
                                      serviceWidget(widget.ad.service3),
                                      serviceWidget(widget.ad.service4),
                                    ],
                                  ),
                                ),
                                Expanded(
                                  child: Column(
                                    children: [
                                      Expanded(
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.end,
                                          children: [
                                            Flexible(
                                              flex: 5,
                                              child: Text(
                                                widget.ad.location,
                                                textScaleFactor: 0.65,
                                                overflow: TextOverflow.ellipsis,
                                                style: const TextStyle(
                                                    color: Colors.black),
                                              ),
                                            ),
                                            const Flexible(
                                              child: FittedBox(
                                                child: Padding(
                                                  padding: EdgeInsets.all(2.0),
                                                  child: Icon(
                                                    Icons.location_pin,
                                                    color: kSecondary,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Expanded(
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.end,
                                          children: [
                                            Flexible(
                                              flex: 5,
                                              child: Text(
                                                "${widget.ad.timing}hrs. service",
                                                textScaleFactor: 0.85,
                                                overflow: TextOverflow.ellipsis,
                                                style: const TextStyle(
                                                    color: Colors.black),
                                              ),
                                            ),
                                            const Flexible(
                                              child: FittedBox(
                                                child: Padding(
                                                  padding: EdgeInsets.all(2.0),
                                                  child: Icon(
                                                    Icons.watch_later_rounded,
                                                    color: kSecondary,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Expanded(
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.end,
                                          children: [
                                            Flexible(
                                              flex: 5,
                                              child: Text(
                                                widget.ad.workType,
                                                textScaleFactor: 0.85,
                                                overflow: TextOverflow.ellipsis,
                                                style: const TextStyle(
                                                    color: Colors.black),
                                              ),
                                            ),
                                            const Flexible(
                                              child: FittedBox(
                                                child: Padding(
                                                  padding: EdgeInsets.all(2.0),
                                                  child: Icon(
                                                    Icons.build_rounded,
                                                    color: kSecondary,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Column(
                        children: [
                          const Flexible(
                            child: Divider(
                              thickness: 1.5,
                            ),
                          ),
                          Flexible(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Expanded(
                                  flex: 3,
                                  child: GestureDetector(
                                    onTap: () => requestCallback(),
                                    child: Row(
                                      children: const [
                                        Expanded(
                                          child: FittedBox(
                                            child: Icon(
                                              Icons.call_rounded,
                                              color: kSecondary,
                                            ),
                                          ),
                                        ),
                                        Expanded(
                                          flex: 4,
                                          child: FittedBox(
                                            child: Text(
                                              "Arrange callback",
                                              style: TextStyle(
                                                  color: Colors.black),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                const Flexible(
                                  child: RotatedBox(
                                    quarterTurns: 1,
                                    child: Divider(
                                      thickness: 1.5,
                                    ),
                                  ),
                                ),
                                Expanded(
                                  flex: 3,
                                  child: GestureDetector(
                                    onTap: () async {
                                      try {
                                        await browser.open(
                                          url: Uri.parse(
                                              'http://onlineroadservices.com/'),
                                          options:
                                              ChromeSafariBrowserClassOptions(
                                            android:
                                                AndroidChromeCustomTabsOptions(
                                              addDefaultShareMenuItem: true,
                                            ),
                                            ios: IOSSafariOptions(
                                              barCollapsingEnabled: true,
                                            ),
                                          ),
                                        );
                                      } catch (e) {
                                        Fluttertoast.showToast(
                                          msg: e.toString(),
                                          gravity: ToastGravity.BOTTOM,
                                          backgroundColor: kPrimary,
                                          textColor: Colors.white,
                                        );
                                      }
                                    },
                                    child: Row(
                                      children: const [
                                        Expanded(
                                          child: FittedBox(
                                            child: Icon(
                                              Icons.language_rounded,
                                              color: kSecondary,
                                            ),
                                          ),
                                        ),
                                        Expanded(
                                          flex: 4,
                                          child: FittedBox(
                                            child: Text(
                                              "Vendor Website",
                                              style: TextStyle(
                                                  color: Colors.black),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                const Flexible(
                                  child: RotatedBox(
                                    quarterTurns: 1,
                                    child: Divider(
                                      thickness: 1.5,
                                    ),
                                  ),
                                ),
                                Expanded(
                                  flex: 3,
                                  child: Row(
                                    children: const [
                                      Expanded(
                                        child: FittedBox(
                                          child: Icon(
                                            Icons.remove_red_eye_rounded,
                                            color: kSecondary,
                                          ),
                                        ),
                                      ),
                                      Expanded(
                                        flex: 4,
                                        child: FittedBox(
                                          child: Text(
                                            "View ad' details",
                                            style:
                                                TextStyle(color: Colors.black),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
