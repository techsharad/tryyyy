package com.ors.ors

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
